# GUI Agent Training System

This repository contains the implementation for training GUI agents using reinforcement learning. The system has two main components:

- **Rollouter**: Manages GUI environments and collects trajectories
- **Trainer**: Optimizes the agent policy using GRPO algorithm

## Installation

```bash
conda create -n verl python=3.9
conda activate verl
pip install -r requirements.txt
```

## Usage

### 1. Launch Rollouter

The rollouter manages GUI environments and collects agent trajectories.

```bash
cd rollouter/
bash run.sh
```

**Before running**, configure `rollouter/config/config_dynamic_rollouter.yaml`:
- Set `task.task_file` to your task file path
- Set `model.ckpt_path` to your model checkpoint
- Configure MySQL database credentials
- Set environment server URL and token

### 2. Launch Trainer

The trainer performs policy optimization using collected trajectories.

```bash
cd trainer/examples/osworld/async/
bash train.sh
```

**Before running**, configure environment variables in `train.sh`:
- `ROOT_DATA_DIR`: Path to data directory
- `RUN_ID`: Unique identifier for this run
- `ROLLOUT_SERVER_URL`: URL of the rollouter (default: `http://localhost:<your port>`)
- `MODEL_PATH`: Path to the pretrained model

## Key Configuration Files

- `rollouter/config/config_dynamic_rollouter.yaml`: Rollouter configuration
- `trainer/examples/osworld/async/train.sh`: Training hyperparameters

## Directory Structure

```
.
├── rollouter/              # Environment manager
│   ├── run.sh             # Launch script
│   └── config/
├── trainer/               # Policy optimizer
│   ├── examples/osworld/async/
│   │   └── train.sh      # Training launch script
│   ├── verl/             # RL training framework
│   └── mm_agents/        # Agent model
└── validation/           # Validation scripts
```

## Notes

- The system uses MySQL for coordination between rollouter and trainer
- Training checkpoints are saved in `checkpoints/verl_osworld_grpo/`
- Default rollouter port is <your port>

## License

Apache License 2.0

