import asyncio
import os
import uvicorn
import argparse
from typing import List, Dict, Any, Optional, Union
import subprocess
import aiohttp
import time
from contextlib import asynccontextmanager
import pynvml
import logging
import logging.handlers
import json
import hydra
from omegaconf import DictConfig, OmegaConf

from fastapi import FastAPI, HTTPException, status, Depends
from pydantic import BaseModel, Field

import socket  
from datetime import datetime

from vllm.utils import F

def set_logger(log_file: str = "logs/model_service.log", log_level: int = logging.INFO):
    
    
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    log_file = f"logs/model_service_{timestamp}.log"
    
    logger = logging.getLogger('model_service')
    logger.setLevel(log_level)
    
    
    if not logger.handlers:
        
        file_handler = logging.handlers.RotatingFileHandler(
            log_file, maxBytes=50*1024*1024, backupCount=100)  # 50MB per file, keep 5 backups
        file_handler.setLevel(log_level)
        
        
        console_handler = logging.StreamHandler()
        console_handler.setLevel(log_level)
        
        
        formatter = logging.Formatter(
            '%(asctime)s - %(funcName)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
    logger.info(f"Logger initialized with log file: {log_file}")
    return logger


logger = set_logger()


# -------------------------------------------------------------------------

# -------------------------------------------------------------------------

class ModelConfig(BaseModel):
    
ckpt_path: str = Field(..., description=" /data/models/llama-2-7b-chat-hf")
base_port: int = Field(8000, description="vLLM")
replicas: int = Field(1, description="")
vllm_params: Dict[str, Any] = Field(default_factory=dict, description="vLLM")
    
class Message(BaseModel):
    role: str
    content: Union[str, List[Dict[str, Any]]]

class GenerationRequest(BaseModel):
    messages: List[Dict[str, Any]]
    parameters: Optional[Dict[str, Any]] = None

class TokenizeRequest(BaseModel):
    prompt: str
    parameters: Optional[Dict] = None
    
 
class ReloadRequest(BaseModel):
new_ckpt_path: str = Field(..., description="")
batch_size: int = Field(1, description="", gt=0)


# -------------------------------------------------------------------------

# -------------------------------------------------------------------------

class ServiceInstance:
    
    def __init__(self, port: int, gpu_id: int, process: subprocess.Popen, ckpt_path: str):
        self.port = port
        self.gpu_id = gpu_id
        self.process = process
        self.endpoint = f"http://localhost:{port}"
        self.requests_in_flight = 0
        self.ckpt_path = ckpt_path

    def __repr__(self):
        return f"<ServiceInstance(port={self.port}, gpu_id={self.gpu_id}, pid={self.process.pid})>"


class GPUInstance:
    
    def __init__(self, gpu_id: int, gpu_memory_utilization: float = 0.9):
        self.gpu_id = gpu_id
        self.gpu_memory_utilization = gpu_memory_utilization
        self.is_available = False
        self._handle = None
        
        
        self._initialize_gpu()
        self.check_and_set_availability()

    def _initialize_gpu(self):
        
        try:
            pynvml.nvmlInit()
            self._handle = pynvml.nvmlDeviceGetHandleByIndex(self.gpu_id)
        except pynvml.NVMLError as e:
            logger.error(f"Failed to initialize GPU {self.gpu_id}: {e}")
            self._handle = None

    def check_and_set_availability(self, gpu_memory_utilization: float = None) -> bool:
        
        if gpu_memory_utilization is None:
            gpu_memory_utilization = self.gpu_memory_utilization
            
        if self._handle is None:
            self.is_available = False
            return False
            
        try:
            memory_info = pynvml.nvmlDeviceGetMemoryInfo(self._handle)
            total_memory = memory_info.total
            free_memory = memory_info.free
            required_memory = int(total_memory * gpu_memory_utilization)
            self.is_available = free_memory >= required_memory
            return self.is_available
        except pynvml.NVMLError as e:
            logger.error(f"Error checking GPU {self.gpu_id} availability: {e}")
            self.is_available = False
            return False

    def __del__(self):
        
        try:
            self._handle = None
        except Exception:
            pass

    def __repr__(self):
        return f"<GPUInstance(gpu_id={self.gpu_id}, is_available={self.is_available})>"
    
    def get_memory_info(self) -> dict:
        
        if self._handle is None:
            return {}
        try:
            memory_info = pynvml.nvmlDeviceGetMemoryInfo(self._handle)
            return {
                'total': memory_info.total,
                'free': memory_info.free,
                'used': memory_info.used
            }
        except pynvml.NVMLError:
            return {}


class ModelServicePool:
    
    def __init__(self, model_cfg: ModelConfig):
        logger.info("Initializing ModelServicePool...")
        self.model_cfg = model_cfg
        self.default_ckpt_path = model_cfg.ckpt_path
        self.last_ckpt_path = model_cfg.ckpt_path
        self.base_port = model_cfg.base_port
        self.replicas = model_cfg.replicas
        self.vllm_params = model_cfg.vllm_params
        self.gpu_memory_utilization = model_cfg.vllm_params.get("gpu_memory_utilization", 0.9)
        
        
        self.instances_lock = asyncio.Lock()  
        self.gpu_lock = asyncio.Lock()        
        self.config_lock = asyncio.Lock()     
        
        # {gpu_id: ServiceInstance}
        self.service_instances: Dict[int, ServiceInstance] = {}
        # {gpu_id: GPUInstance}
        self.gpu_instances: Dict[int, GPUInstance] = {}
        
        self.monitoring_task: Optional[asyncio.Task] = None

    async def initialize(self):    
        
        try:
            gpu_count = self._get_gpu_count()
            if gpu_count == 0:
                raise RuntimeError("No available GPUs found. Cannot start ModelServicePool.")
            
            self.replicas = min(self.model_cfg.replicas, gpu_count)
            if self.replicas < self.model_cfg.replicas:
                logger.warning(f"Warning: Requested replicas ({self.model_cfg.replicas}) > available GPU count ({gpu_count}). "
                      f"Setting replicas to {self.replicas}.")
            
            await self._init_gpu_instances()
            logger.info(await self.get_gpu_info())

            
            instances = await self._start_initial_services()

            logger.info("Waiting for model service pool to become ready...")
            if not await self.wait_for_model_pool_ready(instances):
                raise RuntimeError("Model service pool did not become ready within timeout.")
            else:
                logger.info("Model service pool is ready. Adding instances to pool...")
                async with self.instances_lock:
                    for instance in instances:
                        self.service_instances[instance.gpu_id] = instance

            
            self.monitoring_task = asyncio.create_task(self._monitor_replicas())
            
            logger.info("ModelServicePool initialized and monitoring started.")
            return True

        except Exception as e:
            logger.error(f"Error during ModelServicePool initialization: {e}")
            await self.shutdown()
            return False

    async def shutdown(self):
        
        logger.info("Final shutdown sequence initiated.")
        if self.monitoring_task and not self.monitoring_task.done():
            self.monitoring_task.cancel()
        await self._shutdown_all_services()
        logger.info("ModelServicePool has been shut down.")

    async def _init_gpu_instances(self) -> List[GPUInstance]:
        
        gpu_count = self._get_gpu_count()
        for gpu_id in range(gpu_count):
            self.gpu_instances[gpu_id] = GPUInstance(gpu_id, self.gpu_memory_utilization)

    async def _start_initial_services(self) -> List[ServiceInstance]:
        
        logger.info(f"Starting {self.replicas} initial model services...")
        
        
        async with self.gpu_lock:
            available_gpus = [
                instance.gpu_id for instance in self.gpu_instances.values() 
                if instance.is_available
            ]
        
        if not available_gpus:
            logger.warning("No available GPUs to start initial services.")
            return []

        gpus_to_use = available_gpus[:min(self.replicas, len(available_gpus))]
        
        
        ports_to_use = await self._find_available_ports(len(gpus_to_use))
        
        if len(ports_to_use) < len(gpus_to_use):
            logger.warning(f"Warning: Only found {len(ports_to_use)} available ports for {len(gpus_to_use)} GPUs")
            gpus_to_use = gpus_to_use[:len(ports_to_use)]
        
        logger.info(f"Using GPUs: {gpus_to_use}, Ports: {ports_to_use}")
        
        
        tasks = [
            self._add_new_service_instance(port, gpu_id, self.default_ckpt_path) 
            for port, gpu_id in zip(ports_to_use, gpus_to_use)
        ]
        instances = await asyncio.gather(*tasks)
        
        return instances

    async def add_service_by_id(self, gpu_id: int):
        
        ports = await self._find_available_ports(1)
        if not ports:
            return None
        
        port_to_use = ports[0]
        instance = await self._add_new_service_instance(port_to_use, gpu_id, self.default_ckpt_path)

        if not await self.wait_for_model_pool_ready([instance]):
            return None
        return instance

    async def _add_new_service_instance(self, port: int, gpu_id: int, ckpt_path: str) -> ServiceInstance:
        
        logger.info(f"Attempting to start service on port {port} with GPU {gpu_id} from ckpt_path {ckpt_path}...")
        
        
        async with self.gpu_lock:
            if gpu_id in self.gpu_instances:
                self.gpu_instances[gpu_id].is_available = False
        
        proc = self._launch_vllm_process(port, gpu_id, ckpt_path)
        if not proc:
            logger.error(f"Failed to launch process on port {port}.")
            
            async with self.gpu_lock:
                if gpu_id in self.gpu_instances:
                    self.gpu_instances[gpu_id].is_available = True
            raise RuntimeError(f"Failed to launch vLLM process on GPU {gpu_id}")
        
        instance = ServiceInstance(port, gpu_id, proc, ckpt_path)
        logger.info(f"Successfully started service instance: {instance}")
        
        
        asyncio.create_task(self._stream_process_output(proc, port))

        return instance

    def _launch_vllm_process(self, port: int, gpu_id: int, ckpt_path: str) -> Optional[subprocess.Popen]:
        
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
        
        vllm_command = [
            "vllm", "serve", ckpt_path,
            "--trust-remote-code",
            "--port", str(port)
        ]

        
        for key, value in self.vllm_params.items():
            cli_key = f"--{key}"
            
            if value == "store_true":
                vllm_command.append(cli_key)
            elif value is not None:
                
                vllm_command.append(cli_key)
                vllm_command.append(str(value))
                
        logger.info(f"Launching vLLM command: {vllm_command}")
        
        try:
            return subprocess.Popen(
                vllm_command, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE,
                env=env, 
                bufsize=1, 
                universal_newlines=True
            )
        except (OSError, FileNotFoundError) as e:
            logger.error(f"Error launching vLLM process on port {port}: {e}")
            return None

    async def _remove_service_instance(self, gpu_id: int, kill: bool = False):
        
        instance = None
        async with self.instances_lock:
            instance = self.service_instances.pop(gpu_id, None)

        if not instance:
            logger.warning(f"No service instance found on GPU {gpu_id} to remove.")
            return

        logger.info(f"Shutting down service on GPU {gpu_id}, port {instance.port} (PID: {instance.process.pid if instance.process else 'N/A'})...")
        
        if instance.process and instance.process.poll() is None:
            proc = instance.process
            try:
                
                if kill:
                    proc.kill()
                else:
                    proc.terminate()
                
                
                await asyncio.wait_for(asyncio.to_thread(proc.wait), timeout=10)
                
            except asyncio.TimeoutError:
                
                logger.warning(f"Process {proc.pid} did not terminate gracefully. Force killing...")
                try:
                    proc.kill()
                    await asyncio.wait_for(asyncio.to_thread(proc.wait), timeout=5)
                except (asyncio.TimeoutError, ProcessLookupError):
                    logger.warning(f"Process {proc.pid} already terminated or inaccessible")
            
            
            try:
                os.killpg(os.getpgid(proc.pid), 9)
            except (ProcessLookupError, OSError, PermissionError):
                pass
        
        
        async with self.gpu_lock:
            if gpu_id in self.gpu_instances:
                self.gpu_instances[gpu_id].is_available = True
                logger.info(f"GPU {gpu_id} has been marked as available again")
        
        logger.info(f"Service on GPU {gpu_id} has been completely removed and GPU released")

    async def _shutdown_all_services(self):
        
        logger.info("Shutting down all model services...")
        
        
        async with self.instances_lock:
            gpu_ids = list(self.service_instances.keys())
        
        shutdown_tasks = [self._remove_service_instance(gpu_id) for gpu_id in gpu_ids]
        await asyncio.gather(*shutdown_tasks)
        
        async with self.instances_lock:
            self.service_instances.clear()

    async def _shutdown_n_services(self, gpu_ids: List[int]):
        
        logger.info(f"Attempting to remove services on GPUs: {gpu_ids}")
        if not gpu_ids:
            return []

        shutdown_tasks = [self._remove_service_instance(gpu_id) for gpu_id in gpu_ids]
        await asyncio.gather(*shutdown_tasks)
        return gpu_ids
    
    async def _add_n_service_instance(self, count: int):
        
        logger.info(f"Attempting to add {count} new model service(s)...")
        if count <= 0:
            return []

        
        async with self.gpu_lock:
            available_gpus = [
                gpu.gpu_id for gpu in self.gpu_instances.values()
                if gpu.check_and_set_availability()
            ]

        if not available_gpus:
            logger.warning("Warning: No available GPUs to start new services.")
            return []

        gpus_to_use = available_gpus[:min(count, len(available_gpus))]
        logger.info(f">>>>>>> gpu to run {gpus_to_use}")
        
        if len(gpus_to_use) < count:
            logger.warning(f"Warning: Not enough free GPUs. Will start {len(gpus_to_use)} instead of {count}.")

        
        ports_to_use = await self._find_available_ports(len(gpus_to_use))
        
        if len(ports_to_use) < len(gpus_to_use):
            logger.warning(f"Warning: Not enough free ports. Starting {len(ports_to_use)} services.")
            gpus_to_use = gpus_to_use[:len(ports_to_use)]

        if not gpus_to_use:
            return []

        logger.info(f"Starting services on GPUs: {gpus_to_use}, Ports: {ports_to_use}")
        
        
        tasks = [
            self._add_new_service_instance(port, gpu_id, self.default_ckpt_path) 
            for port, gpu_id in zip(ports_to_use, gpus_to_use)
        ]
        instances = await asyncio.gather(*tasks)
        
        
        if not await self.wait_for_model_pool_ready(instances):
            raise Exception("add new instance failed")
        
        
        async with self.instances_lock:
            for instance in instances:
                self.service_instances[instance.gpu_id] = instance
        
        return True

    async def _monitor_replicas(self):
        
        await asyncio.sleep(120)
        while True:
            try:
                await self._check_all_service_health()
                await self._ensure_replicas()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in monitoring task: {e}")
            await asyncio.sleep(30)

    async def _ensure_replicas(self):
        
        
        async with self.instances_lock:
            current_service_gpus = set(self.service_instances.keys())
            num_active = len(current_service_gpus)

        if num_active >= self.replicas:
            return

        logger.info(f"Replica check: Found {num_active}/{self.replicas} active instances. Attempting to restore...")
        needed = self.replicas - num_active
        
        
        async with self.gpu_lock:
            available_gpus = [
                instance.gpu_id for instance in self.gpu_instances.values() 
                if instance.check_and_set_availability()
            ]
        
        
        ports_to_create = await self._find_available_ports(min(len(available_gpus), needed))
        
        if not available_gpus:
            logger.warning("Warning: Cannot restore replicas, no free GPUs available.")
            return

        num_to_start = min(len(ports_to_create), len(available_gpus), needed)
        
        if num_to_start > 0:
            logger.info(f"Found resources to start {num_to_start} new instance(s).")
            
            
            tasks = [
                self._add_new_service_instance(
                    ports_to_create[i], 
                    available_gpus[i], 
                    self.default_ckpt_path
                ) for i in range(num_to_start)
            ]
            instances = await asyncio.gather(*tasks)
            
            
            if not await self.wait_for_model_pool_ready(instances):
                raise Exception("add new instance failed")
            
            
            async with self.instances_lock:
                for instance in instances:
                    self.service_instances[instance.gpu_id] = instance

    async def _check_all_service_health(self):
        
        logger.info("Checking health of all running services...")
        
        
        async with self.instances_lock:
            current_instances = list(self.service_instances.values())
        
        if not current_instances:
            return
        
        health_checks = [
            self._check_service_health(instance.port) 
            for instance in current_instances
        ]
        results = await asyncio.gather(*health_checks, return_exceptions=True)
        
        
        unhealthy_instances = []
        for instance, is_healthy in zip(current_instances, results):
            if isinstance(is_healthy, Exception) or not is_healthy:
                logger.warning(f"Service on GPU {instance.gpu_id} (port {instance.port}) is unhealthy. Attempting to remove.")
                unhealthy_instances.append(instance.gpu_id)
            else:
                logger.info(f"Service on GPU {instance.gpu_id} (port {instance.port}) is healthy.")
        
        
        if unhealthy_instances:
            removal_tasks = [
                self._remove_service_instance(gpu_id) 
                for gpu_id in unhealthy_instances
            ]
            await asyncio.gather(*removal_tasks)

    async def _check_service_health(self, port: int, timeout: int = 5) -> bool:
        
        url = f"http://localhost:{port}/health"
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as session:
                async with session.get(url) as response:
                    return response.status == 200
        except Exception:
            return False

    async def _wait_for_service_ready(self, instance: ServiceInstance, timeout: int = 1200) -> bool:
        
        start_time = time.time()
        logger.info(f"Waiting for service on GPU {instance.gpu_id} to be ready...")
        
        while time.time() - start_time < timeout:
            if not instance.process or instance.process.poll() is not None:
                logger.error(f"Process for GPU {instance.gpu_id} exited prematurely.")
                return False

            if await self._check_service_health(instance.port):
                logger.info(f"Service on GPU {instance.gpu_id} (port {instance.port}) is ready.")
                return True
            
            
            await asyncio.sleep(1)
        
        logger.error(f"Timeout: Service on GPU {instance.gpu_id} did not become ready within {timeout}s.")
        return False

    async def wait_for_model_pool_ready(self, instances: List[ServiceInstance], timeout: int = 600):
        
        if not instances:
            return False
            
        ports = [inst.port for inst in instances]
        
        logger.info(f"Waiting for {len(ports)} service(s) to become ready (timeout: {timeout}s)...")
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            num_ready = 0
            tasks = [self._check_service_health(port) for port in ports]
            results = await asyncio.gather(*tasks)
            
            for result in results:
                if isinstance(result, bool) and result:
                    num_ready += 1
            
            if num_ready >= len(ports):
                logger.info(f"All {len(ports)} service(s) are ready.")
                return True
            
            
            await asyncio.sleep(1)
        
        logger.error(f"Timeout: {len(instances)} service(s) did not become ready within {timeout}s.")
        return False

    def _get_gpu_count(self) -> int:
        
        if "CUDA_VISIBLE_DEVICES" in os.environ:
            devices = os.environ["CUDA_VISIBLE_DEVICES"]
            if devices:
                return len(devices.split(","))
        try:
            result = subprocess.run(["nvidia-smi", "-L"], capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                return len([line for line in lines if line.startswith('GPU ')])
        except (subprocess.SubprocessError, FileNotFoundError):
            pass
        return 0

    def _get_available_gpus(self) -> List[int]:
        
        return list(range(self._get_gpu_count()))

    # async def _stream_process_output(self, proc: subprocess.Popen, port: int):
    
    #     async def reader(stream, prefix):
    #         while True:
    #             line = await asyncio.to_thread(stream.readline)
    #             if not line:
    #                 break
    
    #             clean_line = line.rstrip()
    
    #             import re
    #             ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    #             clean_line = ansi_escape.sub('', clean_line)
    #             logger.info(f"[{prefix}] {clean_line}")

    #     stdout_task = asyncio.create_task(reader(proc.stdout, f"Port {port} STDOUT"))
    #     stderr_task = asyncio.create_task(reader(proc.stderr, f"Port {port} STDERR"))
        
    #     return_code = await asyncio.to_thread(proc.wait)
    #     logger.info(f"Process for port {port} terminated with return code {return_code}.")
        
    #     stdout_task.cancel()
    #     stderr_task.cancel()

    async def _stream_process_output(self, proc: subprocess.Popen, port: int, max_log_length: int = 400):
        
        import re
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')

        async def reader(stream, prefix):
            while True:
                line = await asyncio.to_thread(stream.readline)
                if not line:
                    break

                clean_line = ansi_escape.sub('', line.rstrip())

                
                if len(clean_line) > max_log_length:
                    clean_line = f"{clean_line[:max_log_length]}... (truncated {len(clean_line) - max_log_length} chars)"

                logger.info(f"[{prefix}] {clean_line}")

        stdout_task = asyncio.create_task(reader(proc.stdout, f"Port {port} STDOUT"))
        stderr_task = asyncio.create_task(reader(proc.stderr, f"Port {port} STDERR"))

        return_code = await asyncio.to_thread(proc.wait)
        logger.info(f"Process for port {port} terminated with return code {return_code}.")

        stdout_task.cancel()
        stderr_task.cancel()
        
    
    @asynccontextmanager
    async def _get_endpoint_for_request(self):
        
        instance = None
        try:
            async with self.instances_lock:
                active_instances = list(self.service_instances.values())
                if not active_instances:
                    raise Exception("No available endpoints in the pool.")
                
                instance = min(active_instances, key=lambda x: x.requests_in_flight)
                instance.requests_in_flight += 1
            
            logger.info(f"Routing request to {instance.endpoint} (GPU {instance.gpu_id}, in-flight: {instance.requests_in_flight})")
            yield instance
        
        finally:
            if instance:
                async with self.instances_lock:
                    instance.requests_in_flight -= 1

    async def generate(self, messages: List[Dict[str, Any]], **kwargs) -> str:
        
        try:
            async with self._get_endpoint_for_request() as instance:
                logger.info(f"Using Service Instance ->>> {instance}")
                if not instance:
                    raise HTTPException(
                        status_code=status.HTTP_503_SERVICE_UNAVAILABLE, 
                        detail="Model service pool is not ready or has no available endpoints."
                    )
                
                url = f"{instance.endpoint}/v1/chat/completions"
                data = {"model": instance.ckpt_path, "messages": messages, **kwargs}
                # logger.debug(f"messages -> {messages}")
                async with aiohttp.ClientSession() as session:
                    async with session.post(url, json=data) as response:
                        if not response.ok:
                            error_text = await response.text()
                            raise HTTPException(status_code=response.status, detail=f"API call failed: {error_text}")
                        
                        response_data = await response.json()
                        try:
                            return response_data
                        except (KeyError, IndexError, TypeError) as e:
                            raise HTTPException(
                                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, 
                                detail=f"Failed to parse response: {e}. Full response: {response_data}"
                            )

        except Exception as e:
            logger.error(f"Error during generate call: {e}")
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))
        
    async def tokenize(self, input_text: str, **kwargs) -> Dict[str, Any]:
        
        try:
            async with self._get_endpoint_for_request() as instance:
                logger.info(f"Using Service Instance for tokenize ->>> {instance}")
                if not instance:
                    raise HTTPException(
                        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                        detail="Model service pool is not ready or has no available endpoints."
                    )

                url = f"{instance.endpoint}/tokenize"
                data = {"model": instance.ckpt_path, "prompt": input_text}

                async with aiohttp.ClientSession() as session:
                    async with session.post(url, json=data) as response:
                        if not response.ok:
                            error_text = await response.text()
                            raise HTTPException(status_code=response.status, detail=f"Tokenize API failed: {error_text}")
                        
                        response_data = await response.json()
                        try:
                            return response_data
                        except (KeyError, IndexError, TypeError) as e:
                            raise HTTPException(
                                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                detail=f"Failed to parse tokenize response: {e}. Full response: {response_data}"
                            )
        except Exception as e:
            logger.error(f"Error during tokenize call: {e}")
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

    async def _find_available_ports(self, count: int, start_port: int = None, continuous: bool = False) -> List[int]:
        
        if start_port is None:
            start_port = self.base_port
            
        available_ports = []
        port = start_port
        max_port = start_port + 1000  
        
        def _check_port_bind(port_num: int) -> bool:
            
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    s.bind(("0.0.0.0", port_num))
                    return True
            except OSError:
                return False
        
        while len(available_ports) < count and port <= max_port:
            is_free = await asyncio.to_thread(_check_port_bind, port)
            
            if is_free:
                if continuous and available_ports and port != available_ports[-1] + 1:
                    available_ports.clear()
                    available_ports.append(port)
                else:
                    available_ports.append(port)
                
                if len(available_ports) == count:
                    break
            else:
                if continuous and available_ports:
                    available_ports.clear()
            
            port += 1
            
        if len(available_ports) < count:
            logger.warning(f"Warning: Could only find {len(available_ports)}/{count} available ports")
            
        return available_ports[:count]

    async def reload(self, new_ckpt_path: str):
        
        logger.info(f"\n--- Reloading model pool to: {new_ckpt_path} ---")
        
        
        async with self.config_lock:
            self.default_ckpt_path = new_ckpt_path
        
        
        if self.monitoring_task and not self.monitoring_task.done():
            self.monitoring_task.cancel()
        
        
        await self._shutdown_all_services()
        
        
        await self.initialize()
        
        logger.info("--- Model pool reloaded successfully ---")
        return True

    
    async def roll_reload(self, new_ckpt_path: str, batch_size: int = 1):
        

        if self.replicas >= 4:
            batch_size = max(2, batch_size)
        if self.replicas < 4:
            batch_size = 1

        logger.info(f"\n--- Rolling reload to new model: {new_ckpt_path} (batch size: {batch_size}) ---")
        
        
        if self.monitoring_task and not self.monitoring_task.done():
            logger.info("pause monitoring task")
            self.monitoring_task.cancel()

        
        async with self.instances_lock:
            old_instances_gpu_ids = [
                inst.gpu_id for inst in self.service_instances.values()
                if inst.ckpt_path != new_ckpt_path
            ]
        
        logger.info(f">>>>> old gpu ids : {old_instances_gpu_ids}")
        
        if not old_instances_gpu_ids:
            logger.info("All instances are already running the target model. Reload skipped.")
            
            self.monitoring_task = asyncio.create_task(self._monitor_replicas())
            return True

        
        async with self.config_lock:
            self.last_ckpt_path = self.default_ckpt_path
            self.default_ckpt_path = new_ckpt_path

        
        for i in range(0, len(old_instances_gpu_ids), batch_size):
            batch_gpu_ids = old_instances_gpu_ids[i:i + batch_size]
            logger.info(f"--- Reloading batch: GPUs {batch_gpu_ids} ---")

            
            logger.info(f"Removing {len(batch_gpu_ids)} old instance(s)...")
            await self._shutdown_n_services(batch_gpu_ids)
            
            
            logger.info(f"Adding {len(batch_gpu_ids)} new instance(s) with new model...")
            await self._add_n_service_instance(len(batch_gpu_ids))
            
            
            await asyncio.sleep(0)

        
        logger.info("restart monitoring task")
        self.monitoring_task = asyncio.create_task(self._monitor_replicas())
        logger.info(f"--- Rolling reload finished with new model: {new_ckpt_path} ---")
        return True

    async def get_endpoints(self) -> List[str]:
        
        async with self.instances_lock:
            return [instance.endpoint for instance in self.service_instances.values()]

    async def get_status(self) -> List[Dict]:
        
        async with self.instances_lock:
            return [
                {
                    "gpu_id": inst.gpu_id,
                    "port": inst.port,
                    "endpoint": inst.endpoint,
                    "ckpt_path": inst.ckpt_path,
                    "requests_in_flight": inst.requests_in_flight,
                    "pid": inst.process.pid if inst.process else None
                }
                for inst in self.service_instances.values()
            ]
    
    async def get_gpu_info(self) -> List[Dict]:
        
        async with self.gpu_lock:
            return [
                {
                    "gpu_id": ginst.gpu_id,
                    "is_available": ginst.is_available
                }
                for ginst in self.gpu_instances.values()
            ]
    
    async def get_checkpoint_info(self) -> Dict[str, Optional[str]]:
        
        async with self.config_lock:
            return {
                "current_ckpt_path": self.default_ckpt_path,
                "last_ckpt_path": self.last_ckpt_path
            }


# -------------------------------------------------------------------------

# -------------------------------------------------------------------------


@hydra.main(config_path="config", config_name="config", version_base="1.3")
def main(cfg: DictConfig):
    
    
    
    logger.info(OmegaConf.to_yaml(cfg))

    
    model_cfg = ModelConfig(
        ckpt_path=cfg.model.ckpt_path,
        base_port=cfg.model.base_port,
        replicas=cfg.model.replicas,
        vllm_params=OmegaConf.to_container(cfg.model.vllm_params)
    )

    
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.model_pool = ModelServicePool(model_cfg)
        
        if not await app.state.model_pool.initialize():
            logger.error("Fatal error: ModelServicePool initialization failed. Exiting.")
            raise RuntimeError("ModelServicePool initialization failed.")
        
        yield
        
        await app.state.model_pool.shutdown()

    
    app = FastAPI(lifespan=lifespan)
    
    
    def get_model_pool() -> ModelServicePool:
        
        return app.state.model_pool

    
    @app.get("/")
    async def read_root():
        return {"message": "Model Service is running."}

    @app.post("/generate")
    async def generate_text(request: GenerationRequest, pool: ModelServicePool = Depends(get_model_pool)):
        
        try:
            kwargs = request.parameters or {}
            response_data = await pool.generate(request.messages, **kwargs)
            return response_data
        except HTTPException as e:
            raise e
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, 
                detail=f"An unexpected error occurred: {str(e)}"
            )

    @app.post("/tokenize")
    async def tokenize_text(request: TokenizeRequest, pool: ModelServicePool = Depends(get_model_pool)):
        kwargs = request.parameters or {}
        return await pool.tokenize(request.prompt, **kwargs)
    @app.post("/reload", summary="Reload model with rolling update")
    async def reload_model(request: ReloadRequest, pool: ModelServicePool = Depends(get_model_pool)):
        
        asyncio.create_task(pool.roll_reload(request.new_ckpt_path, request.batch_size))
        return {"message": "Model rolling reload process initiated successfully."}

    @app.post("/remove_service_by_id", summary="Remove a service instance by gpu id")
    async def remove_service(gpu_id: int, pool: ModelServicePool = Depends(get_model_pool)):
        
        try:
            await pool._remove_service_instance(gpu_id)
            return {"message": f"Service instance on GPU {gpu_id} removed successfully."}
        except Exception as e:
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

    @app.post("/add_service_by_id", summary="Add a service instance by gpu id")
    async def add_service(gpu_id: int, pool: ModelServicePool = Depends(get_model_pool)):
        
        try:
            await pool.add_service_by_id(gpu_id)
            return {"message": f"Service instance on GPU {gpu_id} added successfully."}
        except Exception as e:
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

    @app.get("/status", summary="Get service pool status")
    async def get_status(pool: ModelServicePool = Depends(get_model_pool)):
        
        status_info = await pool.get_status()
        return {
            "replicas_configured": pool.replicas,
            "active_services_count": len(status_info),
            "instances": status_info
        }
    
    @app.get("/gpu_info", summary="All GPU information")
    async def get_gpu_info(pool: ModelServicePool = Depends(get_model_pool)):
        gpu_info = await pool.get_gpu_info()
        return gpu_info
    
    @app.get("/shutdown")
    async def shutdown(pool: ModelServicePool = Depends(get_model_pool)):
        
        await pool.shutdown()
        return {"message": "All model services have been shut down."}
    
    @app.get("/endpoints")
    async def get_endpoints(pool: ModelServicePool = Depends(get_model_pool)):
        
        endpoints = await pool.get_endpoints()
        return {"endpoints": endpoints}
    
    @app.get("/checkpoint_info", summary="Get checkpoint path information")
    async def get_checkpoint_info(pool: ModelServicePool = Depends(get_model_pool)):
        
        checkpoint_info = await pool.get_checkpoint_info()
        return checkpoint_info
    
    uvicorn.run(app, host=cfg.model.host, port=cfg.model.service_port)


if __name__ == "__main__":
    main()