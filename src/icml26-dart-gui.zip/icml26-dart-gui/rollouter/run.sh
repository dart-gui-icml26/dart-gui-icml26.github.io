#!/usr/bin/env bash


source <CONDA_PATH>/bin/activate 
conda activate verl
cd <PROJECT_PATH>/rollouter/
set -euo pipefail

mkdir -p <PROJECT_PATH>/rollouter/gpu_util_log
MONITOR_ID="<PROJECT_PATH>/rollouter/gpu_util_log/gpu_monitor_$(date +%Y%m%d_%H%M%S)_$$"
nohup nvidia-smi --query-gpu=index,timestamp,name,pci.bus_id,driver_version,pstate,pcie.link.gen.max,pcie.link.gen.current,temperature.gpu,utilization.gpu,utilization.memory,memory.total,memory.free,memory.used --format=csv -l 1 > "${MONITOR_ID}.csv" 2>&1 &


PORT="${PORT:-<your port>}"
HEALTH_ENDPOINT="${HEALTH_ENDPOINT:-http://localhost:${PORT}}"
STARTUP_TIMEOUT="${STARTUP_TIMEOUT:-600}"     
POLL_INTERVAL="${POLL_INTERVAL:-10}"           
TERMINATE_GRACE_SECONDS="${TERMINATE_GRACE_SECONDS:-5}"  

export PYTHONUNBUFFERED=1


if ! command -v curl >/dev/null 2>&1; then
echo "[FATAL] curl " >&2
  exit 127
fi

MODEL_PID=""
RUN_PID=""


forward_to_run() {
echo "[INFO] run.py ..."
  if [[ -n "${RUN_PID}" ]] && kill -0 "${RUN_PID}" 2>/dev/null; then
    kill -TERM "${RUN_PID}" 2>/dev/null || true
  fi
}
trap forward_to_run INT TERM


cleanup_model() {
  if [[ -n "${MODEL_PID}" ]] && kill -0 "${MODEL_PID}" 2>/dev/null; then
echo "[INFO] （PID=${MODEL_PID}）"
    kill "${MODEL_PID}" 2>/dev/null || true
    
    for ((i=0; i<TERMINATE_GRACE_SECONDS*10; i++)); do
      kill -0 "${MODEL_PID}" 2>/dev/null || break
      sleep 0.1
    done
    
    if kill -0 "${MODEL_PID}" 2>/dev/null; then
echo "[WARN] ${TERMINATE_GRACE_SECONDS}s SIGKILL"
      kill -9 "${MODEL_PID}" 2>/dev/null || true
    fi
  fi
}
trap cleanup_model EXIT


echo "[INFO] : python model_service.py"
python -u model_service.py &
MODEL_PID=$!
echo "[INFO] PID=${MODEL_PID}"


echo "[INFO] ${HEALTH_ENDPOINT} （ ${STARTUP_TIMEOUT}s）..."
SECONDS=0
while true; do
  
  if ! kill -0 "${MODEL_PID}" 2>/dev/null; then
echo "[ERROR] "
    exit 1
  fi
  
  if RESP="$(curl -fsS "${HEALTH_ENDPOINT}" 2>/dev/null || true)"; then
    if grep -q '"Model Service is running."' <<<"${RESP}"; then
echo "[INFO] ${RESP}"
      break
    fi
  fi
(( SECONDS >= STARTUP_TIMEOUT )) && { echo "[ERROR] "; exit 1; }
  sleep "${POLL_INTERVAL}"
done


echo "[INFO] : python run.py $*"
python -u run.py "$@" &
RUN_PID=$!


wait "${RUN_PID}"; RUN_EXIT=$?
echo "[INFO] run.py =${RUN_EXIT}"


exit "${RUN_EXIT}"