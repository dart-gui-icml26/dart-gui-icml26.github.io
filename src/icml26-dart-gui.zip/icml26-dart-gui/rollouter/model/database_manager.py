

import asyncio
import aiomysql
import yaml
import logging
import os
from typing import Dict, Any, Optional, List, Tuple
from contextlib import asynccontextmanager
from pathlib import Path

logger = logging.getLogger(__name__)


class DatabaseManager:
    
    
    def __init__(self, config_path: str = None):
        
        self.pool: Optional[aiomysql.Pool] = None
        self.config = self._load_config(config_path)
        self._lock = asyncio.Lock()
        
    def _load_config(self, config_path: str = None) -> Dict[str, Any]:
        
        if config_path is None:
            
            current_dir = Path(__file__).parent.parent
            config_path = current_dir / "config" / "db_config.yaml"
            
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
                logger.info(f": {config_path}")
                return config
        except Exception as e:
            logger.error(f": {e}")
            raise
    
    async def initialize(self):
        
        if self.pool is not None:
            logger.warning("")
            return
            
        async with self._lock:
            if self.pool is not None:
                return
                
            try:
                db_config = self.config['database']
                pool_config = db_config['pool']
                conn_config = db_config['connection']
                
                self.pool = await aiomysql.create_pool(
                    host=db_config['host'],
                    port=db_config['port'],
                    user=db_config['username'],
                    password=db_config['password'],
                    db=db_config['database'],
                    charset=db_config['charset'],
                    minsize=pool_config['min_size'],
                    maxsize=pool_config['max_size'],
                    pool_recycle=pool_config['max_recycle_sec'],
                    connect_timeout=conn_config['connect_timeout'],
                    autocommit=conn_config['autocommit']
                )
                
                logger.info(f" - "
                          f"host: {db_config['host']}:{db_config['port']}, "
                          f"database: {db_config['database']}, "
                          f"pool_size: {pool_config['min_size']}-{pool_config['max_size']}")
                          
            except Exception as e:
                logger.error(f": {e}")
                raise
    
    async def close(self):
        
        if self.pool is not None:
            self.pool.close()
            await self.pool.wait_closed()
            self.pool = None
            logger.info("")
    
    @asynccontextmanager
    async def get_connection(self):
        
        if self.pool is None:
            await self.initialize()
            
        connection = None
        try:
            connection = await self.pool.acquire()
            yield connection
        except Exception as e:
            logger.error(f": {e}")
            raise
        finally:
            if connection is not None:
                self.pool.release(connection)
    
    @asynccontextmanager 
    async def get_cursor(self, connection=None):
        
        if connection is not None:
            
            cursor = await connection.cursor(aiomysql.DictCursor)
            try:
                yield cursor
            finally:
                await cursor.close()
        else:
            
            async with self.get_connection() as conn:
                cursor = await conn.cursor(aiomysql.DictCursor)
                try:
                    yield cursor
                finally:
                    await cursor.close()
    
    async def execute_query(self, sql: str, params: Tuple = None) -> List[Dict[str, Any]]:
        
        try:
            async with self.get_cursor() as cursor:
                await cursor.execute(sql, params)
                result = await cursor.fetchall()
                logger.debug(f" - SQL: {sql}, : {len(result)}")
                return result
        except Exception as e:
            logger.error(f" - SQL: {sql}, : {e}")
            raise
    
    async def execute_insert(self, sql: str, params: Tuple = None) -> int:
        
        try:
            async with self.get_connection() as conn:
                async with self.get_cursor(conn) as cursor:
                    await cursor.execute(sql, params)
                    await conn.commit()
                    insert_id = cursor.lastrowid
                    logger.debug(f" - SQL: {sql}, ID: {insert_id}")
                    return insert_id
        except Exception as e:
            logger.error(f" - SQL: {sql}, : {e}")
            raise
    
    async def execute_update(self, sql: str, params: Tuple = None) -> int:
        
        try:
            async with self.get_connection() as conn:
                async with self.get_cursor(conn) as cursor:
                    await cursor.execute(sql, params)
                    await conn.commit()
                    affected_rows = cursor.rowcount
                    logger.debug(f" - SQL: {sql}, : {affected_rows}")
                    return affected_rows
        except Exception as e:
            logger.error(f" - SQL: {sql}, : {e}")
            raise
    
    async def execute_delete(self, sql: str, params: Tuple = None) -> int:
        
        try:
            async with self.get_connection() as conn:
                async with self.get_cursor(conn) as cursor:
                    await cursor.execute(sql, params)
                    await conn.commit()
                    deleted_rows = cursor.rowcount
                    logger.debug(f" - SQL: {sql}, : {deleted_rows}")
                    return deleted_rows
        except Exception as e:
            logger.error(f" - SQL: {sql}, : {e}")
            raise
    
    async def execute_transaction(self, operations: List[Tuple[str, Tuple]]):
        
        try:
            async with self.get_connection() as conn:
                async with conn.begin():  
                    async with self.get_cursor(conn) as cursor:
                        for sql, params in operations:
                            await cursor.execute(sql, params)
                    
                logger.info(f" {len(operations)} ")
        except Exception as e:
            logger.error(f": {e}")
            raise
    
    async def check_connection(self) -> bool:
        
        try:
            async with self.get_cursor() as cursor:
                await cursor.execute("SELECT 1")
                result = await cursor.fetchone()
                return result is not None
        except Exception as e:
            logger.error(f": {e}")
            return False


_db_manager: Optional[DatabaseManager] = None


async def get_db_manager() -> DatabaseManager:
    
    global _db_manager
    if _db_manager is None:
        _db_manager = DatabaseManager()
        await _db_manager.initialize()
    return _db_manager


async def close_db_manager():
    
    global _db_manager
    if _db_manager is not None:
        await _db_manager.close()
        _db_manager = None