

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from dataclasses import dataclass

from .database_manager import get_db_manager

logger = logging.getLogger(__name__)


@dataclass
class Checkpoint:
    
    id: Optional[int] = None
    name: str = ""
    path: str = ""
    version: str = ""
    remark: Optional[str] = None
    status: int = 0  
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    deleted_at: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        
        return {
            'id': self.id,
            'name': self.name,
            'path': self.path,
            'version': self.version,
            'remark': self.remark,
            'status': self.status,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
            'deleted_at': self.deleted_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Checkpoint':
        
        return cls(
            id=data.get('id'),
            name=data.get('name', ''),
            path=data.get('path', ''),
            version=data.get('version', ''),
            remark=data.get('remark'),
            status=data.get('status', 0),
            created_at=data.get('created_at'),
            updated_at=data.get('updated_at'),
            deleted_at=data.get('deleted_at')
        )


class CheckpointModel:
    
    
    def __init__(self):
        self.table_name = "checkpoint"
    
    async def create(self, checkpoint: Checkpoint) -> int:
        
        try:
            db = await get_db_manager()
            sql = """
                INSERT INTO checkpoint (name, path, version, remark, status)
                VALUES (%s, %s, %s, %s, %s)
            """
            params = (
                checkpoint.name,
                checkpoint.path,
                checkpoint.version,
                checkpoint.remark,
                checkpoint.status
            )
            
            checkpoint_id = await db.execute_insert(sql, params)
            logger.info(f"checkpoint - ID: {checkpoint_id}, name: {checkpoint.name}, version: {checkpoint.version}")
            return checkpoint_id
            
        except Exception as e:
            logger.error(f"checkpoint - name: {checkpoint.name}, : {e}")
            raise
    
    async def get_by_id(self, checkpoint_id: int) -> Optional[Checkpoint]:
        
        try:
            db = await get_db_manager()
            sql = """
                SELECT id, name, path, version, remark, status, 
                       created_at, updated_at, deleted_at
                FROM checkpoint 
                WHERE id = %s AND deleted_at IS NULL
            """
            
            result = await db.execute_query(sql, (checkpoint_id,))
            if result:
                return Checkpoint.from_dict(result[0])
            return None
            
        except Exception as e:
            logger.error(f"IDcheckpoint - ID: {checkpoint_id}, : {e}")
            raise
    
    async def get_by_version(self, version: str) -> Optional[Checkpoint]:
        
        try:
            db = await get_db_manager()
            sql = """
                SELECT id, name, path, version, remark, status, 
                       created_at, updated_at, deleted_at
                FROM checkpoint 
                WHERE version = %s AND deleted_at IS NULL
            """
            
            result = await db.execute_query(sql, (version,))
            if result:
                return Checkpoint.from_dict(result[0])
            return None
            
        except Exception as e:
            logger.error(f"checkpoint - version: {version}, : {e}")
            raise
    
    async def get_all(self, status: Optional[int] = None, limit: int = 100, offset: int = 0) -> List[Checkpoint]:
        
        try:
            db = await get_db_manager()
            
            if status is not None:
                sql = """
                    SELECT id, name, path, version, remark, status, 
                           created_at, updated_at, deleted_at
                    FROM checkpoint 
                    WHERE status = %s AND deleted_at IS NULL
                    ORDER BY updated_at DESC
                    LIMIT %s OFFSET %s
                """
                params = (status, limit, offset)
            else:
                sql = """
                    SELECT id, name, path, version, remark, status, 
                           created_at, updated_at, deleted_at
                    FROM checkpoint 
                    WHERE deleted_at IS NULL
                    ORDER BY updated_at DESC
                    LIMIT %s OFFSET %s
                """
                params = (limit, offset)
            
            result = await db.execute_query(sql, params)
            checkpoints = [Checkpoint.from_dict(row) for row in result]
            
            logger.debug(f"checkpoint - : {len(checkpoints)}, status: {status}")
            return checkpoints
            
        except Exception as e:
            logger.error(f"checkpoint - : {e}")
            raise
    
    async def get_available_checkpoints(self) -> List[Checkpoint]:
        
        return await self.get_all(status=1)
    
    async def update(self, checkpoint_id: int, **kwargs) -> bool:
        
        try:
            if not kwargs:
                logger.warning(f"checkpoint - ID: {checkpoint_id}")
                return False
            
            
            update_fields = []
            params = []
            
            allowed_fields = ['name', 'path', 'version', 'remark', 'status']
            for field in allowed_fields:
                if field in kwargs:
                    update_fields.append(f"{field} = %s")
                    params.append(kwargs[field])
            
            if not update_fields:
                logger.warning(f"checkpoint - ID: {checkpoint_id}")
                return False
            
            params.append(checkpoint_id)
            
            db = await get_db_manager()
            sql = f"""
                UPDATE checkpoint 
                SET {', '.join(update_fields)}, updated_at = CURRENT_TIMESTAMP
                WHERE id = %s AND deleted_at IS NULL
            """
            
            affected_rows = await db.execute_update(sql, params)
            success = affected_rows > 0
            
            if success:
                logger.info(f"checkpoint - ID: {checkpoint_id}, : {list(kwargs.keys())}")
            else:
                logger.warning(f"checkpoint - ID: {checkpoint_id}")
            
            return success
            
        except Exception as e:
            logger.error(f"checkpoint - ID: {checkpoint_id}, : {e}")
            raise
    
    async def update_status(self, checkpoint_id: int, status: int) -> bool:
        
        return await self.update(checkpoint_id, status=status)
    
    async def soft_delete(self, checkpoint_id: int) -> bool:
        
        try:
            db = await get_db_manager()
            sql = """
                UPDATE checkpoint 
                SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                WHERE id = %s AND deleted_at IS NULL
            """
            
            affected_rows = await db.execute_update(sql, (checkpoint_id,))
            success = affected_rows > 0
            
            if success:
                logger.info(f"checkpoint - ID: {checkpoint_id}")
            else:
                logger.warning(f"checkpoint - ID: {checkpoint_id}")
            
            return success
            
        except Exception as e:
            logger.error(f"checkpoint - ID: {checkpoint_id}, : {e}")
            raise
    
    async def hard_delete(self, checkpoint_id: int) -> bool:
        
        try:
            db = await get_db_manager()
            sql = "DELETE FROM checkpoint WHERE id = %s"
            
            affected_rows = await db.execute_delete(sql, (checkpoint_id,))
            success = affected_rows > 0
            
            if success:
                logger.info(f"checkpoint - ID: {checkpoint_id}")
            else:
                logger.warning(f"checkpoint - ID: {checkpoint_id}")
            
            return success
            
        except Exception as e:
            logger.error(f"checkpoint - ID: {checkpoint_id}, : {e}")
            raise
    
    async def count(self, status: Optional[int] = None) -> int:
        
        try:
            db = await get_db_manager()
            
            if status is not None:
                sql = "SELECT COUNT(*) as count FROM checkpoint WHERE status = %s AND deleted_at IS NULL"
                params = (status,)
            else:
                sql = "SELECT COUNT(*) as count FROM checkpoint WHERE deleted_at IS NULL"
                params = ()
            
            result = await db.execute_query(sql, params)
            count = result[0]['count'] if result else 0
            
            logger.debug(f"checkpoint - : {count}, status: {status}")
            return count
            
        except Exception as e:
            logger.error(f"checkpoint - : {e}")
            raise
    
    async def search_by_name(self, name_pattern: str, limit: int = 100) -> List[Checkpoint]:
        
        try:
            db = await get_db_manager()
            sql = """
                SELECT id, name, path, version, remark, status, 
                       created_at, updated_at, deleted_at
                FROM checkpoint 
                WHERE name LIKE %s AND deleted_at IS NULL
                ORDER BY updated_at DESC
                LIMIT %s
            """
            
            search_pattern = f"%{name_pattern}%"
            result = await db.execute_query(sql, (search_pattern, limit))
            checkpoints = [Checkpoint.from_dict(row) for row in result]
            
            logger.debug(f"checkpoint - : {name_pattern}, : {len(checkpoints)}")
            return checkpoints
            
        except Exception as e:
            logger.error(f"checkpoint - : {name_pattern}, : {e}")
            raise