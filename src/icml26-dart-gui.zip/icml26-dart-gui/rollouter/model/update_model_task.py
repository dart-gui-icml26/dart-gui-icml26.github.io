

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from dataclasses import dataclass

from .database_manager import get_db_manager

logger = logging.getLogger(__name__)


@dataclass
class UpdateModelTask:
    
    id: Optional[int] = None
    checkpoint_id: int = 0
    path: str = ""
    version: str = ""
    type: str = "system"  
    status: int = 0  
    priority: int = 0  
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    remark: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        
        return {
            'id': self.id,
            'checkpoint_id': self.checkpoint_id,
            'path': self.path,
            'version': self.version,
            'type': self.type,
            'status': self.status,
            'priority': self.priority,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
            'started_at': self.started_at,
            'completed_at': self.completed_at,
            'remark': self.remark
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'UpdateModelTask':
        
        return cls(
            id=data.get('id'),
            checkpoint_id=data.get('checkpoint_id', 0),
            path=data.get('path', ''),
            version=data.get('version', ''),
            type=data.get('type', 'system'),
            status=data.get('status', 0),
            priority=data.get('priority', 0),
            created_at=data.get('created_at'),
            updated_at=data.get('updated_at'),
            started_at=data.get('started_at'),
            completed_at=data.get('completed_at'),
            remark=data.get('remark')
        )


class UpdateModelTaskManager:
    
    
    def __init__(self):
        self.table_name = "update_model_task"
        self.valid_types = ['normal', 'system']
self.valid_statuses = {0: '', 1: '', 2: '', 3: ''}
        self.valid_priorities = list(range(10))  # 0-9
    
    async def create(self, task: UpdateModelTask) -> int:
        
        try:
            if task.type not in self.valid_types:
raise ValueError(f": {task.type}, : {self.valid_types}")
            
            if task.status not in self.valid_statuses:
raise ValueError(f": {task.status}, : {list(self.valid_statuses.keys())}")
            
            if task.priority not in self.valid_priorities:
raise ValueError(f": {task.priority}, : {self.valid_priorities}")
            
            db = await get_db_manager()
            sql = """
                INSERT INTO update_model_task 
                (checkpoint_id, path, version, type, status, priority, remark)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            params = (
                task.checkpoint_id,
                task.path,
                task.version,
                task.type,
                task.status,
                task.priority,
                task.remark
            )
            
            task_id = await db.execute_insert(sql, params)
            logger.info(f" - ID: {task_id}, version: {task.version}, "
                       f"checkpoint_id: {task.checkpoint_id}, type: {task.type}")
            return task_id
            
        except Exception as e:
            logger.error(f" - version: {task.version}, : {e}")
            raise
    
    async def get_by_id(self, task_id: int) -> Optional[UpdateModelTask]:
        
        try:
            db = await get_db_manager()
            sql = """
                SELECT id, checkpoint_id, path, version, type, status, priority,
                       created_at, updated_at, started_at, completed_at, remark
                FROM update_model_task 
                WHERE id = %s
            """
            
            result = await db.execute_query(sql, (task_id,))
            if result:
                return UpdateModelTask.from_dict(result[0])
            return None
            
        except Exception as e:
            logger.error(f"ID - ID: {task_id}, : {e}")
            raise
    
    async def get_by_checkpoint_id(self, checkpoint_id: int, limit: int = 100) -> List[UpdateModelTask]:
        
        try:
            db = await get_db_manager()
            sql = """
                SELECT id, checkpoint_id, path, version, type, status, priority,
                       created_at, updated_at, started_at, completed_at, remark
                FROM update_model_task 
                WHERE checkpoint_id = %s
                ORDER BY priority DESC, created_at ASC
                LIMIT %s
            """
            
            result = await db.execute_query(sql, (checkpoint_id, limit))
            tasks = [UpdateModelTask.from_dict(row) for row in result]
            
            logger.debug(f"checkpoint_id - checkpoint_id: {checkpoint_id}, : {len(tasks)}")
            return tasks
            
        except Exception as e:
            logger.error(f"checkpoint_id - checkpoint_id: {checkpoint_id}, : {e}")
            raise
    
    async def get_all(self, status: Optional[int] = None, task_type: Optional[str] = None, 
                     limit: int = 100, offset: int = 0) -> List[UpdateModelTask]:
        
        try:
            db = await get_db_manager()
            
            where_conditions = []
            params = []
            
            if status is not None:
                if status not in self.valid_statuses:
raise ValueError(f": {status}, : {list(self.valid_statuses.keys())}")
                where_conditions.append("status = %s")
                params.append(status)
            
            if task_type is not None:
                if task_type not in self.valid_types:
raise ValueError(f": {task_type}, : {self.valid_types}")
                where_conditions.append("type = %s")
                params.append(task_type)
            
            where_clause = f"WHERE {' AND '.join(where_conditions)}" if where_conditions else ""
            
            sql = f"""
                SELECT id, checkpoint_id, path, version, type, status, priority,
                       created_at, updated_at, started_at, completed_at, remark
                FROM update_model_task 
                {where_clause}
                ORDER BY priority DESC, created_at ASC
                LIMIT %s OFFSET %s
            """
            
            params.extend([limit, offset])
            
            result = await db.execute_query(sql, params)
            tasks = [UpdateModelTask.from_dict(row) for row in result]
            
            logger.debug(f" - : {len(tasks)}, status: {status}, type: {task_type}")
            return tasks
            
        except Exception as e:
            logger.error(f" - : {e}")
            raise
    
    async def get_pending_tasks(self, limit: int = 100) -> List[UpdateModelTask]:
        
        return await self.get_all(status=0, limit=limit)
    
    async def get_latest_task(self) -> Optional[UpdateModelTask]:
        
        tasks = await self.get_all(limit=1)
        return tasks[0] if tasks else None
    
    async def update(self, task_id: int, **kwargs) -> bool:
        
        try:
            if not kwargs:
                logger.warning(f" - ID: {task_id}")
                return False
            
            
            if 'type' in kwargs and kwargs['type'] not in self.valid_types:
raise ValueError(f": {kwargs['type']}, : {self.valid_types}")
            
            if 'status' in kwargs and kwargs['status'] not in self.valid_statuses:
raise ValueError(f": {kwargs['status']}, : {list(self.valid_statuses.keys())}")
            
            if 'priority' in kwargs and kwargs['priority'] not in self.valid_priorities:
raise ValueError(f": {kwargs['priority']}, : {self.valid_priorities}")
            
            
            update_fields = []
            params = []
            
            allowed_fields = ['checkpoint_id', 'path', 'version', 'type', 'status', 'priority', 
                             'started_at', 'completed_at', 'remark']
            for field in allowed_fields:
                if field in kwargs:
                    update_fields.append(f"{field} = %s")
                    params.append(kwargs[field])
            
            if not update_fields:
                logger.warning(f" - ID: {task_id}")
                return False
            
            params.append(task_id)
            
            db = await get_db_manager()
            sql = f"""
                UPDATE update_model_task 
                SET {', '.join(update_fields)}, updated_at = CURRENT_TIMESTAMP
                WHERE id = %s
            """
            
            affected_rows = await db.execute_update(sql, params)
            success = affected_rows > 0
            
            if success:
                logger.info(f" - ID: {task_id}, : {list(kwargs.keys())}")
            else:
                logger.warning(f" - ID: {task_id}")
            
            return success
            
        except Exception as e:
            logger.error(f" - ID: {task_id}, : {e}")
            raise
    
    async def update_status(self, task_id: int, status: int, **kwargs) -> bool:
        
        update_data = {'status': status}
        
        
        if status == 1:  
            update_data['started_at'] = datetime.now()
        elif status in [2, 3]:  
            update_data['completed_at'] = datetime.now()
        
        update_data.update(kwargs)
        return await self.update(task_id, **update_data)
    
    async def start_task(self, task_id: int) -> bool:
        
        return await self.update_status(task_id, 1)
    
    async def complete_task(self, task_id: int, remark: str = None) -> bool:
        
        kwargs = {}
        if remark:
            kwargs['remark'] = remark
        return await self.update_status(task_id, 2, **kwargs)
    
    async def fail_task(self, task_id: int, remark: str = None) -> bool:
        
        kwargs = {}
        if remark:
            kwargs['remark'] = remark
        return await self.update_status(task_id, 3, **kwargs)
    
    async def delete(self, task_id: int) -> bool:
        
        try:
            db = await get_db_manager()
            sql = "DELETE FROM update_model_task WHERE id = %s"
            
            affected_rows = await db.execute_delete(sql, (task_id,))
            success = affected_rows > 0
            
            if success:
                logger.info(f" - ID: {task_id}")
            else:
                logger.warning(f" - ID: {task_id}")
            
            return success
            
        except Exception as e:
            logger.error(f" - ID: {task_id}, : {e}")
            raise
    
    async def count(self, status: Optional[int] = None, task_type: Optional[str] = None) -> int:
        
        try:
            db = await get_db_manager()
            
            where_conditions = []
            params = []
            
            if status is not None:
                if status not in self.valid_statuses:
raise ValueError(f": {status}, : {list(self.valid_statuses.keys())}")
                where_conditions.append("status = %s")
                params.append(status)
            
            if task_type is not None:
                if task_type not in self.valid_types:
raise ValueError(f": {task_type}, : {self.valid_types}")
                where_conditions.append("type = %s")
                params.append(task_type)
            
            where_clause = f"WHERE {' AND '.join(where_conditions)}" if where_conditions else ""
            
            sql = f"SELECT COUNT(*) as count FROM update_model_task {where_clause}"
            
            result = await db.execute_query(sql, params)
            count = result[0]['count'] if result else 0
            
            logger.debug(f" - : {count}, status: {status}, type: {task_type}")
            return count
            
        except Exception as e:
            logger.error(f" - : {e}")
            raise
    
    async def get_tasks_with_checkpoint_info(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        
        try:
            db = await get_db_manager()
            sql = """
                SELECT 
                    umt.id, umt.checkpoint_id, umt.path, umt.version, umt.type,
                    umt.status, umt.priority, umt.created_at, umt.updated_at,
                    umt.started_at, umt.completed_at, umt.remark,
                    cp.name as checkpoint_name, cp.path as checkpoint_path,
                    cp.status as checkpoint_status
                FROM update_model_task umt
                LEFT JOIN checkpoint cp ON umt.checkpoint_id = cp.id
                ORDER BY umt.priority DESC, umt.created_at ASC
                LIMIT %s OFFSET %s
            """
            
            result = await db.execute_query(sql, (limit, offset))
            logger.debug(f"checkpoint - : {len(result)}")
            return result
            
        except Exception as e:
            logger.error(f"checkpoint - : {e}")
            raise
    
    async def create_system_task(self, checkpoint_id: int, path: str, version: str, remark: str = None) -> int:
        
        task = UpdateModelTask(
            checkpoint_id=checkpoint_id,
            path=path,
            version=version,
            type='system',
            status=0,
            priority=9,  
            remark=remark
        )
        
        return await self.create(task)
    
    async def create_normal_task(self, checkpoint_id: int, path: str, version: str, 
                               priority: int = 0, remark: str = None) -> int:
        
        if priority < 0 or priority > 8:
raise ValueError(f"0-8: {priority}")
        
        task = UpdateModelTask(
            checkpoint_id=checkpoint_id,
            path=path,
            version=version,
            type='normal',
            status=0,
            priority=priority,
            remark=remark
        )
        
        return await self.create(task)