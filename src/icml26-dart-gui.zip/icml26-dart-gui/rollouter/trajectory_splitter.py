import os
import json
import copy
from collections import defaultdict

class TrajectorySplitter:
    def __init__(
            self,
            root_dir: str,
            window_size: int = 5,
            stride_size: int = 5,
            text_num: int = 30
        ) -> None:
        
        self.root_dir = root_dir
        self.window_size = window_size
        self.stride_size = stride_size
        self.text_num = max(text_num, 0)    
        print(f"Rollout splitter initialized with window_size={window_size}, stride_size={stride_size}")
        
    def split_and_save(
            self,
            dataset_id: str,
            output_dir: str,
            full_messages: list[dict],
            task_config: dict,
            reward: float
        ) -> int:
        
        print(f"Processing trajectory from memory: {dataset_id}...")
        
        message_chunks = self._split_trajectory(full_messages)
        
        
        os.makedirs(output_dir, exist_ok=True)
        
        output_filenames = []
        for i, messages in enumerate(message_chunks):
            output_data = {
                "task_config": task_config,   
                "messages": messages,
                "source_dataset_id": dataset_id,
                "chunk_index": i,
                "reward": reward
            }
            output_filename = f"{dataset_id}_chunk_{i}.json"
            output_filepath = os.path.join(output_dir, output_filename)
            with open(output_filepath, 'w', encoding='utf-8') as f:
                json.dump(output_data, f, ensure_ascii=False, indent=2)
            output_filenames.append(output_filename)
        
        num_chunks = len(message_chunks)
        if num_chunks > 0:
            print(f"Successfully split {dataset_id} into {num_chunks} chunks in '{output_dir}'.")
        else:
            print(f"Trajectory {dataset_id} did not produce any chunks based on the window/stride settings.")
            
        
        meta = {
            "stride_size": self.stride_size,
            "window_size": self.window_size,
            "num_chunks": num_chunks,
            "output_filenames": output_filenames,
        }
        manifest_path = os.path.join(output_dir, "manifest.json")
        with open(manifest_path, 'w', encoding='utf-8') as mf:
            json.dump(meta, mf, ensure_ascii=False, indent=2)
        print(f"Saved manifest to {manifest_path}.")
            
        return meta
    
    def _split_trajectory(self, dataset: list[dict]) -> list[list[dict]]:
        
        start = 1
        end = start + 2 * self.window_size
        n_msg = len(dataset)
        
        if n_msg < 3:
            return []

        message_chunks = []
        instruction = copy.deepcopy(dataset[1])
        is_first_turn = True

        while end <= n_msg+1:
            assert dataset[start]["role"] == "user", f"Expected 'user' role at index {start}, but got {dataset[start]['role']}"
            
            if len(dataset[start]["content"]) == 1:
                instruction["content"] = instruction["content"][:1]

            item = self._process_item(dataset, copy.deepcopy(instruction), start, end, is_first_turn)
            is_first_turn = False
            
            message_chunks.append(item)
            
            start += 2 * self.stride_size
            end = start + 2 * self.window_size
            
        return message_chunks

    def _process_item(self, dataset: list, instruction: dict, start: int, end: int, is_first_turn: bool) -> list:
        
        system_prompt = dataset[0]
        
        message_body = []
        for i in range(max(start-self.text_num*2, 0), start): 
            if dataset[i]["role"] == "assistant":
                message_body.append(copy.deepcopy(dataset[i]))
        
        current_instruction = copy.deepcopy(instruction)
        
        if is_first_turn:
            message_body.extend(copy.deepcopy(dataset[start+1 : end]))
        else:
            message_body.extend(copy.deepcopy(dataset[start : end]))
            
        item = [
            copy.deepcopy(system_prompt),
            current_instruction,
        ]
        item.extend(message_body)
        
        return item  

    
    # def process_and_save(self, dataset_id: str, output_dir: str):
    #     """
    

    #     Args:
    
    
        
    #     Returns:
    
    #     """
    #     print(f"Processing trajectory: {dataset_id}...")
    #     try:
    #         split_data = self._split_dataset_id(dataset_id)
    #     except FileNotFoundError:
    #         print(f"[Error] Could not find data for dataset_id: {dataset_id} in {self.root_dir}. Skipping.")
    #         return 0
        
    
    #     os.makedirs(output_dir, exist_ok=True)
        
    #     for i, (messages, task_config, reward) in enumerate(split_data):
    
    #         output_data = {
    #             "task_config": task_config,
    #             "messages": messages,
    #             "source_dataset_id": dataset_id,
    #             "chunk_index": i
    #         }
            
    
    #         output_filename = os.path.join(output_dir, f"{dataset_id}_chunk_{i}.json")
            
    
    #         with open(output_filename, 'w', encoding='utf-8') as f:
    #             json.dump(output_data, f, ensure_ascii=False, indent=2)
        
    #     print(f"Successfully split {dataset_id} into {len(split_data)} chunks in '{output_dir}'.")
    #     return len(split_data)

    # def _split_dataset_id(self, dataset_id: str) -> list[tuple[list[dict], dict]]:
    #     """
    
    #     """
    #     dataset_dir = os.path.join(self.root_dir, dataset_id)
    #     message_path = os.path.join(dataset_dir, "final_messages.json")
    #     with open(message_path, 'r', encoding='utf-8') as f:
    #         dataset = json.load(f)
        
    #     config_path = os.path.join(dataset_dir, "task_config.json")
    #     with open(config_path, 'r', encoding='utf-8') as f:
    #         task_config = json.load(f)

    
    
    
    #     end = start + 2 * self.window_size
    #     n_msg = len(dataset)
        
    #     batch_data = []
    
    #     instruction = copy.deepcopy(dataset[1])
    #     is_first_turn = True

    #     while end <= n_msg:
    
    #         assert dataset[start]["role"] == "user", f"Expected 'user' role at index {start}, but got {dataset[start]['role']}"
            
    
    
    #         if len(dataset[start]["content"]) == 1:
    #             instruction["content"] = instruction["content"][:1]

    #         item = self._process_item(dataset, copy.deepcopy(instruction), start, end, is_first_turn)
    #         is_first_turn = False
            
    #         batch_data.append((item, copy.deepcopy(task_config)))
            
    
    #         start += 2 * self.stride_size
    #         end = start + 2 * self.window_size
            
    #     return batch_data

    # def _process_item(self, dataset: list, instruction: dict, start: int, end: int, is_first_turn: bool) -> list:
    #     """
    
    #     """
    #     system_prompt = dataset[0]
        
    
    #     message_body = []
    #     for i in range(max(start-self.text_num*2, 0), start):
    #         if dataset[i]["role"] == "assistant":
    #             message_body.append(copy.deepcopy(dataset[i]))
        
    #     current_instruction = copy.deepcopy(instruction)
        
    
    #     if is_first_turn:
    #         message_body.extend(copy.deepcopy(dataset[start+1 : end]))
    #     else:
    #         message_body.extend(copy.deepcopy(dataset[start : end]))
            
    
    #     item = [
    #         copy.deepcopy(system_prompt),
    #         current_instruction,
    #     ]
    #     item.extend(message_body)
        
    #     return item


def create_dummy_data(base_dir, dataset_id, num_turns=10):
    
    traj_path = os.path.join(base_dir, dataset_id)
    os.makedirs(traj_path, exist_ok=True)
    
    
    with open(os.path.join(traj_path, "task_config.json"), 'w') as f:
        json.dump({"id": f"task_for_{dataset_id}"}, f)
        
    
    messages = [{"role": "system", "content": "You are a helpful assistant."}]
    for i in range(num_turns):
        messages.append({
            "role": "user",
            "content": [{"type": "text", "text": f"User turn {i+1}"}, {"type": "image", "image": f"img_{i+1}"}]
        })
        messages.append({"role": "assistant", "content": f"Assistant response {i+1}"})
    with open(os.path.join(traj_path, "final_messages.json"), 'w') as f:
        json.dump(messages, f, indent=2)
        
def test_on_dummy_data():
    
    
    import tempfile
    import shutil
    
     
    with tempfile.TemporaryDirectory() as temp_dir:
        raw_data_dir = os.path.join(temp_dir, "raw_trajectories")
        processed_data_dir = os.path.join(temp_dir, "processed_chunks")
        
        print(f"Created temporary raw data directory: {raw_data_dir}")
        print(f"Created temporary processed data directory: {processed_data_dir}")

        
        DUMMY_DATASET_ID = "trajectory_abc_123"
        create_dummy_data(raw_data_dir, DUMMY_DATASET_ID, num_turns=12)

        
        # window_size=5, stride_size=5, num_turns=12
        
        
        
        
        splitter = TrajectorySplitter(
            root_dir=raw_data_dir,
            window_size=5,
            stride_size=5
        )

        
        num_chunks = splitter.process_and_save(
            dataset_id=DUMMY_DATASET_ID,
            output_dir=processed_data_dir
        )
        
        
        print("\n--- Verification ---")
        print(f"Number of chunks created: {num_chunks}")
        
        output_files = os.listdir(processed_data_dir)
        print(f"Files found in output directory: {output_files}")
        
        assert num_chunks == 2, f"Expected 2 chunks, but got {num_chunks}"
        assert len(output_files) == 2, f"Expected 2 files in output directory, but found {len(output_files)}"
        
        
        with open(os.path.join(processed_data_dir, output_files[0]), 'r') as f:
            first_chunk_data = json.load(f)
        
        assert "task_config" in first_chunk_data
        assert "messages" in first_chunk_data
        assert "source_dataset_id" in first_chunk_data
        assert first_chunk_data["source_dataset_id"] == DUMMY_DATASET_ID
        print("\nContent of the first chunk looks correct.")
        print(json.dumps(first_chunk_data, indent=2, ensure_ascii=False))

        print("\nRollout splitter test completed successfully!")
    

if __name__ == '__main__':
    
    raw_data_dir = "results/pass@1_all_32env_6model_tmp07_max-texts-35"
    splitter = TrajectorySplitter(
                root_dir=raw_data_dir,
                window_size=5,
                stride_size=5
                )
    
    num_chunks = splitter.process_and_save(
            dataset_id="0a0faba3-5580-44df-965d-f562a99b291c_1754049580762",
            output_dir="results_splitted"
        )
    
    print(f"Number of chunks created: {num_chunks}")