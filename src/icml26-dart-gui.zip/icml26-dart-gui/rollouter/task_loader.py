import asyncio
from typing import List, Optional, Union, Dict, Any
import json
import os
import hashlib
from pathlib import Path
from omegaconf import DictConfig
from dataclasses import dataclass, asdict
import copy
import logging
import random
from prompts import COMPUTER_USE_PROMPT, COMPUTER_USE_PROMPT_WITH_CALL_USER
from log_config import setup_logging


from mysql_rollout import MySQLRolloutORM, DB_CONFIG


setup_logging()
logger = logging.getLogger(__name__)

class TaskLoader:
    def __init__(self, task_cfg: DictConfig, storage_root):
        self.task_file = Path(task_cfg.task_file)
        #self.task_root = Path(task_cfg.task_root)
        self.osworld_root = Path(task_cfg.osworld_root)
        
        self._latest_sha: Optional[str] = None
        self.storage_root = storage_root
        self.resume = task_cfg.resume
        
        self.success_rate_threshold = getattr(task_cfg, 'success_rate_threshold', 1.0)  
        self.min_rollout_n = getattr(task_cfg, 'min_rollout_n', 1)  
        self.run_id = getattr(task_cfg, 'run_id', None)  
        self.db_enabled = getattr(task_cfg, 'db_enabled', False)  
        
        
        self.mysql_orm = None
        if self.db_enabled and self.run_id:
            try:
                self.mysql_orm = MySQLRolloutORM(DB_CONFIG)
                logger.info("MySQL ORM ")
            except Exception as e:
                logger.error(f"MySQL ORM : {e}")
                self.mysql_orm = None
        
        
        # self.task_sample_count: Dict[str, int] = {}
        # import pdb; pdb.set_trace()
        
        self.mapping_task_success: Dict[str, float] = {}
        
        self.mapping_task_counts: Dict[str, float] = {}
        self.mapping_task_dynamic_n: Dict[str, float] = {}

        
        
        self._update_mapping_task_success()

     
    def poll_for_tasks(self) -> List[Dict]:
        """find new tasks json file
        return list of TaskInfo dict if there is new json
        else return []
        """
        self._maybe_refresh_dataset()
        
        
        self._update_mapping_task_success()
        
        tasks_list = [task.to_dict() for task in self._tasks]
        random.shuffle(tasks_list)

        return tasks_list 
    
    def _maybe_refresh_dataset_bak(self):
        
        # check new json
        latest_json = self._find_latest_json()

        if latest_json is None:
            return False # no json file
        
        sha = self._calc_sha1(latest_json)
        if sha == self._latest_sha:
            return False # no change
        
        with open(latest_json) as f:
            data = json.load(f)
            
        raw_tasks = [
            {"task_type": task_type, "task_id": task_id}
            for task_type, task_ids in data.items()
            for task_id in task_ids
        ]
        
        self._tasks = [build_task(raw, self.osworld_root) for raw in raw_tasks]
        self._latest_sha = sha

        logger.info(f": {str(latest_json)}")
        logger.info(f": {len(raw_tasks)}")
        
        return True
    
    def _maybe_refresh_dataset(self):
        
        latest_json = self.task_file
        print("Current tasks file: ", str(latest_json))
        
        with open(latest_json) as f:
            data = json.load(f)
            
        raw_tasks = [
            {"task_type": task_type, "task_id": task_id}
            for task_type, task_ids in data.items()
            for task_id in task_ids
        ]
        
        if self.resume:
            
            filtered_tasks = []
            storage_root = Path(self.storage_root)

            for raw in raw_tasks:
                task_id = str(raw["task_id"])
                task_type_expected = raw["task_type"]

                
                candidate_dirs = [
                    d for d in storage_root.iterdir()
                    if d.is_dir() and d.name.startswith(task_id)
                ]

                
                task_finished = False

                for d in candidate_dirs:
                    cfg_path = d / "task_config.json"
                    if not cfg_path.exists():
print("config")
                        continue

                    try:
                        with cfg_path.open("r", encoding="utf-8") as cf:
                            cfg = json.load(cf)
                    except Exception:
                        continue

                    
                    if cfg.get("raw", {}).get("task_type") != task_type_expected:
                        continue

                    
                    if (d / "reward.txt").exists():
                        task_finished = True
                        break  
                if not task_finished:
                    filtered_tasks.append(raw)
            self._tasks = [build_task(raw, self.osworld_root) for raw in filtered_tasks]
            print(f"Total number of tasks: {len(raw_tasks)}, Remained:{len(filtered_tasks)}")

        else:
            self._tasks = [build_task(raw, self.osworld_root) for raw in raw_tasks]
            print(f"Total number of tasks: {len(raw_tasks)}")

        return True
        
    def _find_latest_json(self) -> Optional[Path]:
        files = list(self.task_root.glob("*.json"))
        return max(files, key=lambda p: p.stat().st_mtime) if files else None
    
    @staticmethod
    def _calc_sha1(fp: Path, chunk_size=2<<20) -> str:
        h = hashlib.sha1()
        with fp.open("rb") as f:
            for chunk in iter(lambda: f.read(chunk_size), b""):
                h.update(chunk)
        return h.hexdigest()

    def _update_mapping_task_success(self):
        
        if not self.mysql_orm or not self.run_id:
            logger.info(" run_id")
            return
        
        try:
            
            # avg_nonneg, count_all, distinct_task_cnt, mapping_task_success = \
            #     self.mysql_orm.get_nth_newest_model_success(self.run_id, 1)
            avg_nonneg, count_all, distinct_task_cnt, mapping_task_success, mapping_task_counts = self.mysql_orm.get_latest_success_for_each_task(self.run_id, self.mapping_task_dynamic_n)
            self.mapping_task_success = mapping_task_success
            self.mapping_task_counts = mapping_task_counts
            logger.info(f" {len(mapping_task_success)} ")
        except Exception as e:
            logger.error(f": {e}")

    def get_dynamic_rollout_n(self, task_id: str, rollout_n) -> int:
        
        
        success_rate = self.mapping_task_success.get(task_id, 0.0)
        traj_counts = self.mapping_task_counts.get(task_id, 0.0)
        
        
        # sample_count = self.task_sample_count.get(task_id, 0)
        
        
        if success_rate < self.success_rate_threshold:
            dynamic_rollout_n = rollout_n
            logger.info(f" {task_id}  {traj_counts}  {success_rate:.2%}  {self.success_rate_threshold:.2%}: {dynamic_rollout_n}")
        else:
            # weight = 1.0 / (success_rate * (sample_count + 1))
            
            # weight = 1.0 / (success_rate * (sample_count + 1) + 1e-8)
            dynamic_rollout_n = int(9 / success_rate - 7)
            dynamic_rollout_n = max(self.min_rollout_n, dynamic_rollout_n)
            logger.info(f" {task_id}  {traj_counts}  {success_rate:.2%}  {self.success_rate_threshold:.2%}: {dynamic_rollout_n} (: {int(9 / success_rate - 7)})")

        
        
        # self.task_sample_count[task_id] = sample_count + 1
        self.mapping_task_dynamic_n[task_id] = dynamic_rollout_n
        logger.info(f" {task_id}  rollout_n: {dynamic_rollout_n} : {success_rate:.2%}")
        return traj_counts, success_rate, dynamic_rollout_n

    def sort_tasks_by_success_rate(self, tasks: List[Dict]) -> List[Dict]:
        
        def sort_key(task):
            task_id = task.get('task_config', {}).get('raw', {}).get('task_id', '')
            
            if task_id not in self.mapping_task_success:
                return (-1, 0)  
            
            return (0, self.mapping_task_success[task_id])
        
        
        return sorted(tasks, key=sort_key)

@dataclass
class TaskInfo:
    messages: List
    instruction: str
    task_config: Dict

    def to_dict(self):
        return asdict(self)


def build_task(raw: Dict, osworld_root: Path, use_call_user: bool = False) -> TaskInfo:

    task_type = raw["task_type"]
    task_id = raw["task_id"]
    task_path = os.path.join(osworld_root, task_type, task_id + ".json")
    with open(task_path) as f:
        task_data = json.load(f)

    task_data["raw"] = {
        "task_type": task_type,
        "task_id": task_id
    }

    instruction = task_data["instruction"]

    # if "human-ground-truth" in task_data and "single-action" in task_data["human-ground-truth"]:
    #     plan = task_data["human-ground-truth"]["single-action"]
    #     plan_text = "\n".join(plan)
    #     instruction = instruction.strip() + "\nHere is an instruction to help you complete the task: \n" + plan_text
    if "human-ground-truth" in task_data and "single-action" in task_data["human-ground-truth"]:
        plan = task_data["human-ground-truth"]["single-action"]
        plan_text = "\n".join(plan)

        plan_mode = "always"
        use_plan = False
        if plan_mode == "always":
            use_plan = True
        elif plan_mode == "never":
            use_plan = False
        elif plan_mode == "random":
            import random
            use_plan = random.choice([True, False])
        else:
            raise ValueError(f"Unknown plan_mode: {plan_mode}")
        
        if use_plan:
            instruction = instruction.strip() + "\nHere is an instruction to help you complete the task: \n" + plan_text

            

    system_prompt = COMPUTER_USE_PROMPT if not use_call_user else COMPUTER_USE_PROMPT_WITH_CALL_USER
    messages = [
        {
            "role": "system",
            "content": "You are a helpful assistant."
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "text", 
                    "text": system_prompt.format(
                        instruction=instruction, 
                        language="English"
                )}
            ]
        }
    ]
    

    return TaskInfo(
        messages = messages,
        instruction = instruction,
        task_config = task_data
    )

