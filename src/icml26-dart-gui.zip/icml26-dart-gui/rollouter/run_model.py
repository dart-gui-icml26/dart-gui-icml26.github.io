from model_service_pool import ModelServicePool
import asyncio
import signal
import sys
import ray
import logging
import hydra
from omegaconf import DictConfig

from log_config import setup_logging


setup_logging()
logger = logging.getLogger(__name__)

ckpt_path = "<MODEL_PATH>"


model_pool = None

async def cleanup():
    
    global model_pool
    if model_pool is not None:
        logger.info("...")
        try:
            await model_pool.shutdown.remote()
            logger.info("")
        except Exception as e:
            logger.error(f": {e}")
    
    
    if ray.is_initialized():
        logger.info("Ray...")
        ray.shutdown()
        logger.info("Ray")

def signal_handler(signum, frame):
    
    logger.info(f" {signum}...")
    asyncio.create_task(cleanup())
    sys.exit(0)

@hydra.main(config_path="config", config_name="config", version_base=None)
def main(config: DictConfig) -> None:
    asyncio.run(async_main(config))

async def async_main(config: DictConfig):
    global model_pool
    
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        
        if not ray.is_initialized():
            ray.init()
        
        
        model_pool = ModelServicePool.remote(model_cfg=config.model)
        
        
        logger.info("...")
        ready = await model_pool.wait_for_model_pool_ready.remote(timeout=600)
        if ready:
            logger.info("")
            endpoints = await model_pool.get_endpoints.remote()
            logger.info(f": {endpoints}")
            
            
            logger.info("...")
            logger.info(" Ctrl+C SIGTERM")
            
            
            
            
            
            
            
            
            try:
                while True:
                    await asyncio.sleep(1)
            except KeyboardInterrupt:
                logger.info("...")
                
        else:
            logger.error("")
            
    except Exception as e:
        logger.error(f": {e}")
    finally:
        
        await cleanup()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("")
