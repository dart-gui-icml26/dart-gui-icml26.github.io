from pathlib import Path
from typing import List, Set
import math

def get_latest_ckpt(dir_path: Path):
    ckpts = list(dir_path.glob("*.safetensors"))
    if not ckpts:
        raise FileNotFoundError("No checkpoint found")

    return max(ckpts, key=lambda p: p.stat().st_mtime)

def choose_images_logspace(img_pos: List[int], k = 5) -> Set[int]:
    
    #k = self.max_images
    n = len(img_pos)

    
    if n <= k:
        return set(img_pos)

    keep_idx: List[int] = []

    
    keep_idx.append(n - 1)

    
    if k > 1:
        log_n = math.log(n)                     # ln(n)
        for j in range(1, k):                  # j = 1 … k-1
            
            d = math.exp(j * log_n / (k - 1)) - 1
            idx = n - 1 - int(round(d))
            keep_idx.append(max(0, min(idx, n - 1)))  

    
    seen = set()
    uniq_keep = [i for i in keep_idx if not (i in seen or seen.add(i))]

    
    if len(uniq_keep) < k:
        for idx in range(n - 1, -1, -1):       
            if idx not in seen:
                uniq_keep.append(idx)
                seen.add(idx)
                if len(uniq_keep) == k:
                    break

    
    return {img_pos[i] for i in uniq_keep}

if __name__ == "__main__":
    print(choose_images_logspace([3,5,7,9,11,13,15,17,19,21,23,25,27,29,31,33,35,37,39,41,43,45,47,49]))