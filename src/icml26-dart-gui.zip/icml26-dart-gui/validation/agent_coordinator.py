import ray
import asyncio
import copy
import time
import logging
import uuid
from typing import List, Dict, Set, Optional
from trajectory_runner import TrajectoryRunnerActor, ResourceExhaustedException
from log_config import setup_logging


setup_logging()
logger = logging.getLogger(__name__)

class AgentCoordinator:

    def __init__(self, coordinator_cfg):
        self.max_concurrent_envs = coordinator_cfg.max_concurrent_envs 
        self.active_tasks: Set[ray.ObjectRef] = set()  
        self.task_queue = asyncio.Queue()  
        self.task_trace_map: Dict[ray.ObjectRef, str] = {}  
        self.poll_count = 0  
        self.max_task_queue_size = coordinator_cfg.max_task_queue_size 
        self.rollout_n = getattr(coordinator_cfg, 'rollout_n', 1)  
        
        
        self.env_cleanup_interval = getattr(coordinator_cfg, 'env_cleanup_interval', 10)  
        self.env_cleanup_timeout = getattr(coordinator_cfg, 'env_cleanup_timeout', 300)  
        self.last_env_cleanup_time = 0  
        self.active_service_ids: Set[str] = set()  
        self.task_to_service_map: Dict[ray.ObjectRef, str] = {}  
        self.task_to_actor_map: Dict[ray.ObjectRef, ray.actor.ActorHandle] = {}  
        
        
        self.should_graceful_exit = False  
        self.exit_reason = ""  
        
        
        self.stats = {
            'total_started': 0,
            'total_completed': 0,
            'total_failed': 0,
            'start_time': time.time()
        }
        
        logger.info(f"AgentCoordinator - : {self.max_concurrent_envs}, : {self.max_task_queue_size} , rollout_n: {self.rollout_n}")
        logger.info(f" - : {self.env_cleanup_interval}, : {self.env_cleanup_timeout}")
        
        
        self._setup_exception_handler()

    def _setup_exception_handler(self):
        
        def exception_handler(loop, context):
            exception = context.get('exception')
            if exception:
                
                if "RayTaskError" in str(type(exception)) or "Failed to get screenshot" in str(exception):
                    
                    logger.debug(f"Ray（）")
                else:
                    logger.error(f": {exception}")
                    logger.error(f": {context}")
            else:
                logger.error(f": {context}")
        
        
        try:
            loop = asyncio.get_running_loop()
            loop.set_exception_handler(exception_handler)
            logger.info("")
        except RuntimeError:
            
            logger.debug("event loop")

    def _generate_trace_id(self) -> str:
        
        return f"trace_{uuid.uuid4().hex[:12]}_{int(time.time())}"
    

    
    async def _cleanup_orphaned_environments(self, runner_cfg):
        
        try:
            
            current_time = time.time()
            time_since_last_cleanup = current_time - self.last_env_cleanup_time
            logger.info(f" - : {time_since_last_cleanup:.1f}, : {self.env_cleanup_interval}")
            
            if time_since_last_cleanup < self.env_cleanup_interval:
                logger.info(f" -  ({time_since_last_cleanup:.1f}s < {self.env_cleanup_interval}s)")
                return  
            
            self.last_env_cleanup_time = current_time
            
            from env_k8s import RemoteDesktopEnv
            from datetime import datetime, timezone, timedelta
            
            
            try:
                all_envs = RemoteDesktopEnv.list_environments(
                    runner_cfg.env.server_url, 
                    runner_cfg.env.user_token
                )
                logger.info(f" -  {len(all_envs)} ")
            except Exception as e:
                logger.error(f": {e}")
                return
            
            if not all_envs:
                logger.debug(" - ")
                return
            
            
            cleanup_stats = {
                'total_envs': len(all_envs),
                'active_envs': len(self.active_service_ids),
                'orphaned_envs': 0,
                'timeout_envs': 0,
                'cleaned_envs': 0,
                'failed_cleanups': 0
            }
            
            logger.info(f" - : {cleanup_stats['total_envs']}, : {cleanup_stats['active_envs']}")
            
            for env in all_envs:
                server_id = env.get('server_id') or env.get('service_id')
                created_at_str = env.get('created_at', '')
                
                if not server_id:
                    logger.warning(f"server_id/service_id: {env}")
                    continue
                
                
                if server_id in self.active_service_ids:
                    logger.debug(f" {server_id} ")
                    continue
                
                cleanup_stats['orphaned_envs'] += 1
                
                
                logger.warning(f"🔍  - Server ID: {server_id}, : {created_at_str}, : {env}")
                
                
                try:
                    if created_at_str:
                        created_at = datetime.fromisoformat(created_at_str)
                        if not created_at:
                            logger.warning(f" {server_id} : {created_at_str}")
                            continue
                        
                        
                        now = datetime.now()  
                        age_seconds = (now - created_at).total_seconds()
                        if age_seconds > 50:
                           logger.info(f" {server_id}  - : {now}, : {created_at}, : {age_seconds:.1f}")
                        
                        
                        if age_seconds < 0:
                            logger.warning(f" {server_id} - : {created_at_str} ({created_at}), : {now}, : {age_seconds:.1f}")
                        else:
                            hours = int(age_seconds // 3600)
                            minutes = int((age_seconds % 3600) // 60)
                            seconds = int(age_seconds % 60)
                            time_str = f"{hours}h{minutes}m{seconds}s" if hours > 0 else f"{minutes}m{seconds}s"
                            logger.info(f" {server_id} - : {created_at_str}, : {time_str} ({age_seconds:.1f})")
                        
                        
                        if age_seconds > self.env_cleanup_timeout:
                            cleanup_stats['timeout_envs'] += 1
                            logger.warning(f"⏰  {server_id}:  {created_at_str},  {time_str} ({age_seconds:.1f}) >  {self.env_cleanup_timeout}")
                            
                            
                            try:
                                from env_k8s import release_single_env
                                success = release_single_env(
                                    runner_cfg.env.server_url, 
                                    runner_cfg.env.user_token, 
                                    server_id
                                )
                                if success:
                                    cleanup_stats['cleaned_envs'] += 1
                                    
                                    
                                    if server_id in self.active_service_ids:
                                        self.active_service_ids.discard(server_id)
                                        logger.info(f"✅ : {server_id}")
                                    else:
                                        logger.info(f"✅ : {server_id}（）")
                                    
                                    
                                    removed_tasks = []
                                    for task_ref, service_id in list(self.task_to_service_map.items()):
                                        if service_id == server_id:
                                            removed_tasks.append(task_ref)
                                            del self.task_to_service_map[task_ref]
                                    
                                    if removed_tasks:
                                        logger.info(f"task_to_service_map {len(removed_tasks)} ")
                                        
                                else:
                                    cleanup_stats['failed_cleanups'] += 1
                                    logger.error(f"❌ : {server_id}")
                            except Exception as e:
                                cleanup_stats['failed_cleanups'] += 1
                                logger.error(f": {server_id}, : {e}")
                        else:
                            logger.debug(f" {server_id}  - : {age_seconds:.1f} < {self.env_cleanup_timeout}")
                    else:
                        logger.warning(f" {server_id} created_at")
                        
                except Exception as e:
                    logger.error(f" {server_id} : {created_at_str}, : {e}")
            
            
            logger.info(f" - "
f": {cleanup_stats['total_envs']}, "
f": {cleanup_stats['active_envs']}, "
f": {cleanup_stats['orphaned_envs']}, "
f": {cleanup_stats['timeout_envs']}, "
f": {cleanup_stats['cleaned_envs']}, "
f"fail: {cleanup_stats['failed_cleanups']}")
                       
        except Exception as e:
            logger.error(f": {e}")
            import traceback
            logger.error(f": {traceback.format_exc()}")
        
        logger.info("")
    
    def _update_active_service_ids(self):
        
        
        
        
        pass

    async def start_rollout(self, task_loader, runner_cfg, model_pool, storage, mysql_writer):
        
        
        try:
            loop = asyncio.get_running_loop()
            if not hasattr(loop, '_exception_handler') or loop._exception_handler is None:
                self._setup_exception_handler()
        except Exception as e:
            logger.warning(f": {e}")
            
        logger.info("")
    
        
        while True:
            try:
                
                if self.should_graceful_exit:
                    logger.info(f": {self.exit_reason}")
                    if self.active_tasks:
                        logger.info(f" {len(self.active_tasks)} ...")
                        
                        try:
                            await asyncio.wait(self.active_tasks, timeout=60.0)  
                        except asyncio.TimeoutError:
                            logger.warning("")
                    logger.info("")
                    break
                
                
                logger.info(" _cleanup_orphaned_environments ")
                await self._cleanup_orphaned_environments(runner_cfg)
                logger.info("_cleanup_orphaned_environments ")
                
                
                if (self.task_queue.empty() and 
                    self.poll_count < self.max_task_queue_size and
                    not self.should_graceful_exit):  

                    new_tasks_batch = task_loader.poll_for_tasks()
                    logger.info(f": {len(new_tasks_batch)}")
                    if new_tasks_batch:
                        self.poll_count += 1  
                        added_count = 0
                        
                        for task in new_tasks_batch:
                            task_id = task.get('task_config', {}).get('id', 'unknown')
                            
                            
                            for rollout_idx in range(self.rollout_n):
                                
                                task_with_trace = copy.deepcopy(task)
                                trace_id = self._generate_trace_id()
                                task_with_trace['trace_id'] = trace_id
                                task_with_trace['rollout_idx'] = rollout_idx  
                                
                                await self.task_queue.put(task_with_trace)
                                added_count += 1
                                
                                logger.info(f"[{trace_id}]  - task_id: {task_id}, rollout_idx: {rollout_idx + 1}/{self.rollout_n}")
                        
                        logger.info(f" {self.poll_count}  {added_count} : {self.task_queue.qsize()}")
                    else:
                        
                        if self.poll_count < self.max_task_queue_size:
                            await asyncio.sleep(1)
                            continue

                
                started_count = 0
                while (len(self.active_tasks) < self.max_concurrent_envs and 
                       not self.task_queue.empty() and
                       not self.should_graceful_exit):  

                    try:
                        task_info = await asyncio.wait_for(self.task_queue.get(), timeout=0.1)
                        trace_id = task_info.get('trace_id', 'unknown_trace')
                        task_id = task_info.get('task_config', {}).get('id', 'unknown')
                        rollout_idx = task_info.get('rollout_idx', 0)
                        
                        logger.info(f"[{trace_id}]  - task_id: {task_id}, rollout_idx: {rollout_idx + 1}/{self.rollout_n}")
                        
                        try:
                            actor = TrajectoryRunnerActor.options(num_cpus=0.5).remote(task_info, runner_cfg)
                            task_ref = actor.run_episode.remote(model_pool, storage, mysql_writer)
                            self.active_tasks.add(task_ref)
                            self.task_trace_map[task_ref] = trace_id
                            self.task_to_actor_map[task_ref] = actor  
                            
                            
                            task_completion = asyncio.create_task(self._track_task_completion(task_ref, task_id, trace_id, rollout_idx))
                            
                            asyncio.create_task(self._track_service_id(task_ref, actor))
                            
                            task_completion.add_done_callback(self._handle_task_exception)
                           
                            self.stats['total_started'] += 1
                            started_count += 1
                            logger.info(f"[{trace_id}]  - task_id: {task_id}, rollout_idx: {rollout_idx + 1}/{self.rollout_n}, : {len(self.active_tasks)}")
                        except ray.exceptions.RayTaskError as e:
                            logger.warning(f"[{trace_id}] Ray: {e}")
                        except Exception as e:
                            logger.error(f"[{trace_id}]  - task_id: {task_id}, rollout_idx: {rollout_idx + 1}/{self.rollout_n}, : {e}")
                            
                    except asyncio.TimeoutError:
                        break  
                
                if started_count > 0:
                    logger.info(f" {started_count} ")

                
                if self.active_tasks:
                    
                    try:
                        done, pending = await asyncio.wait(
                            self.active_tasks, 
                            return_when=asyncio.FIRST_COMPLETED,
                            timeout=1.0  
                        )
                        
                        
                        for task_ref in done:
                            
                            
                            pass
                            
                    except asyncio.TimeoutError:
                        
                        pass
                else:
                    
                    if self.should_graceful_exit:
                        logger.info("")
                        break
                    elif (self.task_queue.empty() and 
                          self.poll_count >= self.max_task_queue_size):
                        logger.info("")
                        break
                    
                    await asyncio.sleep(0.1)
                    
                
                if self.stats['total_started'] % 10 == 0 and self.stats['total_started'] > 0:
                    self._log_stats()
                    
            except Exception as e:
                logger.error(f": {e}")
                
                logger.error("")
                break
        
        
        self._log_stats()
        logger.info("")
        return True  

    async def _track_task_completion(self, task_ref: ray.ObjectRef, task_id: str, trace_id: str, rollout_idx: int):
        
        try:
            start_time = time.time()
            task_failed = False  
            
            try:
                result = await task_ref
                duration = time.time() - start_time
                self.stats['total_completed'] += 1
                logger.info(f"[{trace_id}]  - task_id: {task_id}, rollout_idx: {rollout_idx + 1}/{self.rollout_n}, : {duration:.2f}")
                
            except ResourceExhaustedException as e:
                
                task_failed = True
                duration = time.time() - start_time
                self.stats['total_failed'] += 1
                self.should_graceful_exit = True
self.exit_reason = f""
                logger.error(f"[{trace_id}]  - task_id: {task_id}, : {duration:.2f}, : {e}")
                
            except BaseException as e:
                
                task_failed = True
                duration = time.time() - start_time
                if isinstance(e, Exception):
                    self.stats['total_failed'] += 1
                    
                    error_type = type(e).__name__
                    error_msg = str(e)  
                    logger.error(f"[{trace_id}]  - task_id: {task_id}, rollout_idx: {rollout_idx + 1}/{self.rollout_n}, : {duration:.2f}, : {error_type}: {error_msg}")
                    logger.info(f"[{trace_id}] : {e}")
                    
                    
                    actor = self.task_to_actor_map.get(task_ref)
                    if actor:
                        try:
                            ray.kill(actor)
                            logger.info(f"[{trace_id}] Actor")
                        except Exception as kill_error:
                            logger.warning(f"[{trace_id}] Actor: {kill_error}")
                else:
                    logger.error(f"[{trace_id}]  - task_id: {task_id}, : {duration:.2f}, : {e}")
            
            finally:
                try:
                    
                    self.active_tasks.discard(task_ref)
                    self.task_trace_map.pop(task_ref, None)
                    self.task_to_actor_map.pop(task_ref, None)  
                    
                    
                    service_id = self.task_to_service_map.pop(task_ref, None)
                    if service_id:
                        self.active_service_ids.discard(service_id)
                        logger.info(f"[{trace_id}]  service_id: {service_id}")
                    
                    logger.info(f"[{trace_id}] : {len(self.active_tasks)}")
                        
                except Exception as cleanup_error:
                    logger.error(f"[{trace_id}] : {cleanup_error}")
                    
        except Exception as outer_error:
            logger.error(f"[{trace_id}] _track_task_completion: {outer_error}")
            import traceback
            logger.error(f"[{trace_id}] :\n{traceback.format_exc()}")
        
        except BaseException as system_error:
            logger.error(f"[{trace_id}] _track_task_completion: {system_error}")
        
        
    

    async def _track_service_id(self, task_ref: ray.ObjectRef, actor):
        
        try:
            
          
            env_ready = await actor.wait_for_env_ready.remote(timeout=180.0)
            if not env_ready:
                logger.warning(" - ")
                return
            
            
            service_id = await actor.get_service_id.remote()
            if service_id:
                self.task_to_service_map[task_ref] = service_id
                self.active_service_ids.add(service_id)
                logger.info(f" service_id: {service_id}")
            else:
                
                logger.warning("service_id - （）")
                
        except BaseException as e:
            
            if isinstance(e, Exception):
                logger.warning(f"service_id: {e}")
            else:
                logger.error(f"service_id: {e}")
    
    def _handle_task_exception(self, task):
        
        try:
            if task.exception() is not None:
                exception = task.exception()
                
                if "RayTaskError" in str(type(exception)) or "Failed to get screenshot" in str(exception):
                    
                    logger.error(f"Ray（）: {type(exception).__name__}")
                else:
                    
                    logger.error(f": {exception}")
            else:
                
                logger.debug("")
                            
        except Exception as e:
            logger.error(f": {e}")
            
    def _log_stats(self):
        
        runtime = time.time() - self.stats['start_time']
        success_rate = self.stats['total_completed']/max(1, self.stats['total_completed'] + self.stats['total_failed'])*100
        
        logger.info(f"===  === : {runtime:.1f}, "
f": {self.stats['total_started']}, "
f": {self.stats['total_completed']}, "
                   f"fail: {self.stats['total_failed']}, "
f": {len(self.active_tasks)}, "
f": {self.task_queue.qsize()}, "
f": {self.poll_count}/{self.max_task_queue_size}, "
f": {success_rate:.1f}%")
        

    async def shutdown(self):
        
        logger.info("AgentCoordinator...")
        
        
        if self.active_tasks:
            active_traces = [self.task_trace_map.get(task_ref, 'unknown') for task_ref in self.active_tasks]
            logger.info(f" {len(self.active_tasks)} trace_ids: {active_traces}")
            await asyncio.wait(self.active_tasks, timeout=30.0)  
            
        self._log_stats()
        logger.info("AgentCoordinator")

