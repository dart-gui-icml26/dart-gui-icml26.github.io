import ray
import aiohttp
from typing import List, Dict


@ray.remote
class ModelServicePool:
    
    
    
    def __init__(self, model_cfg):
        
        print("Initializing ModelServicePool...")
        self.service_url = model_cfg.service_endpoint
        print(f"Model Service Endpoint:>>> {self.service_url}")


    async def generate(self, messages: List[Dict[str, str]],  **kwargs) -> str:
        
        payload = {
            "messages": messages,
            "parameters": kwargs
        }
        generate_endpoint = self.service_url + "/generate"
        async with aiohttp.ClientSession() as session:
            async with session.post(generate_endpoint, json=payload) as response:
                if not response.ok:
                    error_text = await response.text()
                    raise Exception(f"API call failed with status {response.status}: {error_text}")
                
                response_data = await response.json()
                try:
                    return response_data["choices"][0]["message"]["content"], response_data["model"]
                except (KeyError, IndexError, TypeError) as e:
                    raise Exception(f"Failed to parse response: {e}. Full response: {response_data}")

    async def reload(self, new_ckpt_path: str, batch_size: int = 1):
        
        payload = {
            "new_ckpt_path": new_ckpt_path,
            "batch_size": batch_size
        }
        reload_endpoint = self.service_url + "/reload"
        async with aiohttp.ClientSession() as session:
            async with session.post(reload_endpoint, json=payload) as response:
                if not response.ok:
                    error_text = await response.text()
                    raise Exception(f"API call failed with status {response.status}: {error_text}")
                
                response_data = await response.json()
                return response_data

    async def shutdown(self): 
        
        shutdown_endpoint = self.service_url + "/shutdown"
        async with aiohttp.ClientSession() as session:
            async with session.get(shutdown_endpoint) as response:
                if not response.ok:
                    error_text = await response.text()
                    raise Exception(f"API call failed with status {response.status}: {error_text}")

    async def get_checkpoint_info(self) -> Dict[str, str]:
        
        checkpoint_endpoint = self.service_url + "/checkpoint_info"
        async with aiohttp.ClientSession() as session:
            async with session.get(checkpoint_endpoint) as response:
                if not response.ok:
                    error_text = await response.text()
                    raise Exception(f"API call failed with status {response.status}: {error_text}")
                
                response_data = await response.json()
                return response_data

    async def get_last_model_version(self) -> str:
        
        checkpoint_info = await self.get_checkpoint_info()
        return checkpoint_info.get("last_ckpt_path", "")


