source <CONDA_PATH>/bin/activate verl

cd <PROJECT_PATH>/validation/

python model_service.py & 
MODEL_SERVICE_PID=$!
sleep 360

python run.py


kill $MODEL_SERVICE_PID 2>/dev/null || true
echo "Model service terminated"


echo "Terminating all Python processes..."
pkill -f python 2>/dev/null || true
sleep 2


echo "Force killing any remaining Python processes..."
pkill -9 -f python 2>/dev/null || true
echo "All Python processes terminated"