import ray
import asyncio
from pathlib import Path
import time
import copy
import os

import hydra
from omegaconf import DictConfig, OmegaConf
import logging


from task_loader import TaskLoader
from agent_coordinator import AgentCoordinator
from model_service_pool import ModelServicePool
from storage_actor import StorageActor
from trajectory_runner import TrajectoryRunnerActor
from split_tasks_util import write_chunk
from env_k8s import release_env
from mysql_writer import MySQLWriterActor

from log_config import setup_logging


setup_logging()
logger = logging.getLogger(__name__)


# set environment variables
@hydra.main(config_path="config", config_name="config", version_base=None)
def main(config: DictConfig) -> None:
    print(OmegaConf.to_yaml(config))
    asyncio.run(async_main(config))

async def async_main(config=None):
    ray.init(log_to_driver=True)

    
    task_loader = TaskLoader(config.task, config.storage.root)
    coordinator = AgentCoordinator(config.coordinator)
    storage = StorageActor.remote(config.storage)
    mysql_writer = MySQLWriterActor.remote(config.mysql)
   
    model_pool = None
    model_pool = ModelServicePool.remote(model_cfg=config.model)
    
    
    
    # ready = await model_pool.wait_for_model_pool_ready.remote(timeout=600)
    # if ready:
    #     replicas = await model_pool.get_replicas.remote()
    
    # else:
    
    
    #     endpoints = await model_pool.get_endpoints.remote()
    
    #     return

     
    release_env(config.env.server_url,config.env.user_token)

    while True:
        try:

            completed = await coordinator.start_rollout(
                task_loader=task_loader,  
                runner_cfg=config.runner,
                model_pool=model_pool,
                storage=storage,
                mysql_writer=mysql_writer
            )
            
            
            if completed:
                logger.info("")
                break
                
        except KeyboardInterrupt:
            logger.info("...")
            break
        except Exception as e:
            logger.error(f": {e}")
            break


# ----- test -----

def test_env():
    task_loader = TaskLoader("./evaluation_examples", "./evaluation_examples/examples")
    tasks_batch = task_loader.poll_for_tasks()
    t = TrajectoryRunnerActor(tasks_batch[0])
    t._init_env(tasks_batch[0]["task_config"])


async def test_run_episode(config): 
    task_loader = TaskLoader("./evaluation_examples", "./evaluation_examples/examples")
    tasks_batch = task_loader.poll_for_tasks()
    storage = StorageActor.remote("./results")
    t = TrajectoryRunnerActor(tasks_batch[0])
    await t.run_episode(None, storage)

if __name__ == "__main__":
    # test_run_episode
    #asyncio.run(test_run_episode())
    
    main()
