

import asyncio
import logging
from datetime import datetime


from model import (
    get_db_manager, close_db_manager,
    Checkpoint, CheckpointModel,
    CurrentModel, CurrentModelManager, 
    UpdateModelTask, UpdateModelTaskManager
)


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def example_checkpoint_operations():
    
    logger.info("=== Checkpoint ===")
    
    checkpoint_model = CheckpointModel()
    
    
    new_checkpoint = Checkpoint(
        name="model_v1.0",
        path="/models/checkpoint_v1.0",
        version="1.0.0",
remark="",
        status=1  
    )
    
    checkpoint_id = await checkpoint_model.create(new_checkpoint)
    logger.info(f"checkpointID: {checkpoint_id}")
    
    
    checkpoint = await checkpoint_model.get_by_id(checkpoint_id)
    if checkpoint:
        logger.info(f"checkpoint: {checkpoint.name}, : {checkpoint.version}")
    
    
    checkpoint_by_version = await checkpoint_model.get_by_version("1.0.0")
    if checkpoint_by_version:
        logger.info(f": {checkpoint_by_version.name}")
    
    
    available_checkpoints = await checkpoint_model.get_available_checkpoints()
    logger.info(f"checkpoint: {len(available_checkpoints)}")
    
    
    success = await checkpoint_model.update_status(checkpoint_id, 0)  
    logger.info(f": {success}")
    
    
    search_results = await checkpoint_model.search_by_name("model")
    logger.info(f": {len(search_results)}")
    
    
    total_count = await checkpoint_model.count()
    available_count = await checkpoint_model.count(status=1)
    logger.info(f": {total_count}, : {available_count}")
    
    return checkpoint_id


async def example_current_model_operations(checkpoint_id: int):
    
    logger.info("=== CurrentModel ===")
    
    current_model_mgr = CurrentModelManager()
    
    
    model_id = await current_model_mgr.activate_model(
        checkpoint_id=checkpoint_id,
        version="1.0.0",
        path="/models/current/v1.0.0",
        activated_by="system_admin",
remark=""
    )
    logger.info(f"ID: {model_id}")
    
    
    model = await current_model_mgr.get_by_id(model_id)
    if model:
        logger.info(f": {model.version}, {model.status}")
    
    
    success = await current_model_mgr.update_status(model_id, "running", "system")
    logger.info(f"running: {success}")
    
    
    running_models = await current_model_mgr.get_running_models()
    logger.info(f": {len(running_models)}")
    
    
    latest_model = await current_model_mgr.get_latest_model()
    if latest_model:
        logger.info(f": {latest_model.version}")
    
    
    models_with_info = await current_model_mgr.get_models_with_checkpoint_info(limit=10)
    logger.info(f": {len(models_with_info)}")
    
    
    total_models = await current_model_mgr.count()
    running_count = await current_model_mgr.count(status="running")
    logger.info(f": {total_models}, : {running_count}")
    
    return model_id


async def example_update_task_operations(checkpoint_id: int):
    
    logger.info("=== UpdateModelTask ===")
    
    task_mgr = UpdateModelTaskManager()
    
    
    system_task_id = await task_mgr.create_system_task(
        checkpoint_id=checkpoint_id,
        path="/models/new/v1.1.0",
        version="1.1.0",
remark="v1.1.0"
    )
    logger.info(f"ID: {system_task_id}")
    
    
    normal_task_id = await task_mgr.create_normal_task(
        checkpoint_id=checkpoint_id,
        path="/models/new/v1.0.1",
        version="1.0.1",
        priority=5,
remark="bug"
    )
    logger.info(f"ID: {normal_task_id}")
    
    
    pending_tasks = await task_mgr.get_pending_tasks(limit=10)
    logger.info(f": {len(pending_tasks)}")
    for task in pending_tasks:
        logger.info(f"  ID: {task.id}, : {task.version}, : {task.priority}")
    
    
    success = await task_mgr.start_task(system_task_id)
    logger.info(f": {success}")
    
    
success = await task_mgr.complete_task(system_task_id, "")
    logger.info(f": {success}")
    
    
success = await task_mgr.fail_task(normal_task_id, "")
    logger.info(f": {success}")
    
    
    latest_task = await task_mgr.get_latest_task()
    if latest_task:
        logger.info(f": {latest_task.version}, : {latest_task.status}")
    
    
    tasks_with_info = await task_mgr.get_tasks_with_checkpoint_info(limit=10)
    logger.info(f": {len(tasks_with_info)}")
    
    
    total_tasks = await task_mgr.count()
    pending_count = await task_mgr.count(status=0)
    completed_count = await task_mgr.count(status=2)
    failed_count = await task_mgr.count(status=3)
    
    logger.info(f" - : {total_tasks}, : {pending_count}, "
f": {completed_count}, : {failed_count}")
    
    return [system_task_id, normal_task_id]


async def example_transaction_operations():
    
    logger.info("===  ===")
    
    db_manager = await get_db_manager()
    
    try:
        
        operations = [
            
            (
                "INSERT INTO checkpoint (name, path, version, status, remark) VALUES (%s, %s, %s, %s, %s)",
("transaction_model", "/models/transaction_test", "tx_1.0.0", 1, "")
            ),
            
            
            (
                "INSERT INTO update_model_task (checkpoint_id, path, version, type, priority, remark) VALUES (%s, %s, %s, %s, %s, %s)",
(1, "/models/transaction_test", "tx_1.0.0", "system", 9, "")
            )
        ]
        
        await db_manager.execute_transaction(operations)
        logger.info("")
        
    except Exception as e:
        logger.error(f": {e}")


async def example_connection_check():
    
    logger.info("===  ===")
    
    db_manager = await get_db_manager()
    
    
    is_connected = await db_manager.check_connection()
    logger.info(f": {'' if is_connected else ''}")


async def main():
    
    try:
        logger.info("")
        
        
        await example_connection_check()
        
        
        checkpoint_id = await example_checkpoint_operations()
        
        
        model_id = await example_current_model_operations(checkpoint_id)
        
        
        task_ids = await example_update_task_operations(checkpoint_id)
        
        
        await example_transaction_operations()
        
        logger.info("")
        
    except Exception as e:
        logger.error(f": {e}")
        raise
    
    finally:
        
        await close_db_manager()
        logger.info("")


if __name__ == "__main__":
    
    asyncio.run(main())