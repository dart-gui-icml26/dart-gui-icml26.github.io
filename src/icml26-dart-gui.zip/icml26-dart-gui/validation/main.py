def main():
    print("Hello from validation!")


if __name__ == "__main__":
    main()
